﻿/*
              *****************************************************************************
              *  Copyright (C)  by Reinhard Heuberger                                     *
              *                                                                           *
              *  All rights reserved.                                                     *
              *                                                                           *
              *  Redistribution and use in source and binary forms, with or without       *
              *  modification, are permitted provided that the following conditions       *
              *  are met:                                                                 *
              *                                                                           *
              *  1. Redistributions of source code must retain the above copyright        *
              *     notice, this list of conditions and the following disclaimer.         *
              *  2. Redistributions in binary form must reproduce the above copyright     *
              *     notice, this list of conditions and the following disclaimer in the   *
              *     documentation and/or other materials provided with the distribution.  *
              *  3. Neither the name of the author nor the names of its contributors may  *
              *     be used to endorse or promote products derived from this software     *
              *     without specific prior written permission.                            *
              *                                                                           *
              *****************************************************************************

                               MFM-DISK clone/Reader/testeer ST506/412/225
                             Beta Version V010  for SoC HPS FPGA-environment
                                       ( Quartus Version 16.1 )
                                       based on DE10-Nano Board
                                 by: Reinhard Heuberger , www.PDP11GY.com
                          https://github.com/pdp11gy/SoC-HPS-based-MFM-disk-emulator

                                 Data - Structure and Mapping:

                         |<-32 MB  SD RAM ->|      |<- DP-RAM-->|

              / 5.898240 +------------------+
             /           |   Cylinder #306  |      +------------+ 20832
   +--------+   5.886720 +------------------+     /|  Track #3  |>15624-20831
   |        |            |                  |    / |- - - - - - | 15624
   |   SD   |            .                  .   /  |  Track #2  |>10416-15623
   |  CARD  |            .                  .  /   |- - - - - - | 10416
   |        |            |                  | /    |  Track #1  |>05208-10415
   +--------+     20832  +------------------+/     |- - - - - - | 05208
             \           |    Cylinder #0   |      |  Track #0  |>00000-05207
              \   00000  +------------------+ - - -+------------+ 00000

       The ST506/412/225 disk drive did have a capacity of 6.38/12.76/20.0MB
                        ST506 = 153 cylinder ,  612 tracks
                        ST412 = 306 cylinder , 1224 tracks
                        ST225 = 615 cylinder , 2460 tracks
                                 32 sectors / track

        Nominal Track Capacity:           =    10416 ( Byte )
        Setzt sich wie folgt zusammen:

        Total Data Bytes/Track = 256   x 32 =     8192
        SYNC = 13x00           =  13   x 32 =      416
        ID AM = 2 Byte         =   2   x 32 =       64
        CYL/HD/SEC = 3 Byte    =   3   x 32 =       96
        Header-CRC = 2 Byte    =   2   x 32 =       64
        Gap2 3 + 13 = 16Byte   =  16   x 32 =      512
        Data AM = 2 Byte       =   2   x 32 =       64
        Data-CRC = 2 Byte      =   2   x 32 =       64
        Gap3 1of2 = 3x00       =   3   x 32 =       96
        Gap3 2of2 = 15x4E      =  15   x 32 =      480
                               ------------------------+-----------------
                         SECTOR: 314      TRACK: 10048 |  CYLINDER: 40192
        Einmalig dazu:   Gap1  16x4E      =         16 |               64
                         Gap4 352x4E      =        352 |             1408
                                       ----------------+-----------------
                             ( Byte )            10416 |            41664
                              ( Bit )            83328 |           333312
                             ( Word )             5208 |            20832
                             ==========================+=================

    APR-2019: Switched to Byte-mode ( Little/Big endian mode is no longer necessarry )

*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>

#include <sys/mman.h>
#include "hwlib.h"
#include "socal/socal.h"
#include "socal/hps.h"
#include "socal/alt_gpio.h"
#include "hps_0.h"
#include <signal.h>
//
//
void init_HW(void);
void startup_leds(void);
void print_binary_16bit_LSB( unsigned short ibit16);
void stepping(void);
void READ_drive_from_FPGA(int point_to_cylinder);
void WRITE_to_SD_Card1(void);
void WRITE_to_SD_Card2(void);
void WRITE_to_SD_Card3(void);
//
//
typedef unsigned char byte;
//
#define HW_REGS_BASE ( ALT_STM_OFST )             // axi_lw
#define HW_REGS_SPAN ( 0x04000000 )               // Bridge span
#define HW_REGS_MASK ( HW_REGS_SPAN - 1 )
#define ALT_AXI_FPGASLVS_OFST (0xC0000000)        // axi_master
#define HW_FPGA_AXI_SPAN (0x40000000)             // Bridge span
#define HW_FPGA_AXI_MASK ( HW_FPGA_AXI_SPAN - 1 )
//
#define CYL_size 20832           // One cylinder size, 16Bit words
#define DPR_size 20832           // Dual-Portet-RAM size, 16Bit words
#define track_size 5208          // One track size, 16Bit words
#define ST506_size 153           // ST506 = 153 cylinder (  5.40 MB )
#define ST412_size 306           // ST412 = 306 cylinder ( 10.16 MB )
#define ST225_size 615           // ST225 = 615 Cylinder ( 20.42 MB )
#define TRUE  1
#define FALSE 0
//
unsigned short int header_index =   7;                             // Header index = 7 (word) (15=byte)
unsigned short int data_start =    19;                             // + 12
unsigned short int data_CRC =     147;                             //    + 128
unsigned short int ST_unit  =       0;                             // current selected ST unit-number
unsigned short int ST_type  =       0;                             // Drive-Type
unsigned short int CYL_P = 15, HD_P = 17, SEC_P = 16;              // point to cylinder,head, sector
unsigned short int DataAM   =       0xA1F8;                        // Indicator Pattern before Data Field
unsigned char DataAM_lsb, DataAM_msb;                              //  split in 2 bytes
//
short int mode=0;                                                  // System operating mode >general
short int cl_mode=0;                                               // System operating mode >clone-mode
unsigned char FOUND=0;                                             // drive found , clone mode
unsigned char DEBUG=0;                                             // DEBUG PURPOSE
unsigned char OFFLINE=0;                                           // online/offline mode
unsigned char OFFMODE=0;                                           // full/simple offline mode
//
/*        *********************** Global Definitions **********************        */
//
//++++++++++++++++++++++++++++++++++ UNION's +++++++++++++++++++++++++++++++++++++++++++++++++++++++++
union std {                                  // ****** ST-506/412 sector ************
       unsigned char  st_c[512];             // Access to one sector via 314 bytes or
       unsigned short st_i[256];             // 157 16Bit words  , alligned to 512/256
       unsigned int   st_l[128];
};
//union  std SECTOR;                                               // define a union of type SECTOR
union  std SECTOR __attribute__ ((aligned(4)));                    // define a union of type SECTOR
union  std *u_stptr;                                               // pointer to union.
//
//
//                     ****** ST-412/506 u. ST225 @ SD-RAM/=union ********
//                     Virtual access to 306 cylinders(head 0 to 3)
//                     4heads: = 1cylinder = 20832 16 bit * 306 = 6374592 = 12749184 Byte
//                     Aligned to 12774400 = 24950 Blocks @ SD-CArd
//                     --Now with ST225 Support:
//                       20832 16 bit * 615 = 12811680 = 25623360 Byte
//                       Aligned to 25625600  = 50050 Blocks @ SD-CArd
union mfm {
       unsigned char  st_drive_c[25625600];    //ST412=12774400
       unsigned short st_drive_i[12812800];    //ST412=6387200
       unsigned int   st_drive_l[6406400];     //ST412=3193600
};
//union  mfm MFMDISK;                                              // define a union of type MFMDISK
union  mfm MFMDISK __attribute__ ((aligned(4)));                   // define a union of type MFMDISK
union  mfm *u_st_drive_ptr;                                        // pointer to union
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//
int SDRAM                   = 12748800;                            // maximum used bytes SD-RAM
int SECsize                 = 512;                                 // Sector size , Byte
unsigned short MAXCYL       =      306;                            // cylinder, ST412/ST506
//
// strcat( myfile2, "ST412_0.STD" ) "ST412_0.STD";
char myfile2[80];
char myfile1[80];
char myfile3[80];
//
//------------------------------------------------------------------------------------------------------
int fd;                                           // Hold FPGA address
void *virtual_base;                               // Virtual axi-lw addr that maps to physical
void *axi_virtual_base;                           // Virtual axi-master addr that maps to physical
void *PIO_0_addr;                                 // PIO-0 address
void *PIO_1_addr;                                 // PIO-1 address
void *PIO_2_addr;
void *PIO_3_addr;
void *DPR;                                        // #1, Dual Ported Ram address
void *DPR_addr;                                   // #1, Dual Ported Ram address with AXI-Master
//void *XDPR;                                     // #2, Dual Ported Ram address
//void *XDPR_addr;                                // #2, Dual Ported Ram address with AXI-Master
void *UART0;                                      // UART_0 address
//------------------------------------------------------------------------------------------------------
//
unsigned char priwhile = 0;
unsigned char secwhile = 0;
//
//
void init_HW(void)
{
  //---------------------------------------------------------------------------------------------------
  // === get FPGA addresses ===
  // Open /dev/mem
  if( ( fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
        printf( "ERROR: could not open \"/dev/mem\"...\n" );
  return; }
  //---------------------------------------------------------------------------------------------------
  // Get virtual addr that maps to physical
  virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );
  if( virtual_base == MAP_FAILED ) {
        printf( "ERROR: mmap() failed...\n" );
        close( fd );
  return; }
  axi_virtual_base = mmap( NULL, HW_FPGA_AXI_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, ALT_AXI_FPGASLVS_OFST );
  //----------------------------------------------------------------------------------------------------
  //
  // Get the addresses that maps to the FPGA control
  PIO_0_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + PIO_0_BASE )
                                & ( unsigned long)( HW_REGS_MASK ) );
  PIO_1_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + PIO_1_BASE )
                                & ( unsigned long)( HW_REGS_MASK ) );
  PIO_2_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + PIO_2_BASE )
                                & ( unsigned long)( HW_REGS_MASK ) );
  PIO_3_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + PIO_3_BASE )
                                & ( unsigned long)( HW_REGS_MASK ) );
  DPR =  virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + DPR_BASE )
                      & ( unsigned long)( HW_REGS_MASK ) );
  DPR_addr =   axi_virtual_base + ( ( unsigned long  )( DPR_BASE ));  // This works with DPR !!!
/*
  XDPR =  virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + XDPR_BASE )
                      & ( unsigned long)( HW_REGS_MASK ) );
  XDPR_addr =   axi_virtual_base + ( ( unsigned long  )( XDPR_BASE ));  // This works with DPR !!!
*/
  UART0 = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + UART_0_BASE )
                      & ( unsigned long)( HW_REGS_MASK ) );
  if( virtual_base == MAP_FAILED ) {
        printf( "ERROR: mmap() failed...\n" );
        close( fd );
        return;
  }
  //-----------------------------------------------------------------------------------------------------
  //
}
//
//
void startup_leds(void)
{
int loop_count;
int led_direction;
int led_mask;
loop_count = 0;
led_mask = 0x01;
led_direction = 0; // 0: left to right direction
    //
    while(loop_count < 3 )  {
      *(uint32_t *)PIO_0_addr = led_mask;
      usleep( 20*1000 );
      if (led_direction == 0){
            led_mask <<= 1;
            if (led_mask == (0x01 << (PIO_0_DATA_WIDTH-1)))
                 led_direction = 1;
        }else{
            led_mask >>= 1;
            if (led_mask == 0x01){
                led_direction = 0;
                loop_count++;
            }
        }
    }
}
//
//
void print_binary_16bit_LSB( unsigned short ibit16)
// Representation: LSB on right site ( PDP-11 like)
{
 int i;
  for (i = 0; i < 16; i++ ){
       if(0x8000 & ibit16 ) {               // Test Bit 15
          printf("1");
          }
           else {
              printf("0");
           }
   ibit16 = ibit16 << 1;
  }
}
//
//
void stepping(void){
    //
    // Generate 1 Step puls. Note:
    //IOWR_ALTERA_AVALON_PIO_DATA(PIO_2_BASE, (cl_mode=cl_mode|0x0100));      // HIGH: Step backward = to Home
    //IOWR_ALTERA_AVALON_PIO_DATA(PIO_2_BASE, (cl_mode=cl_mode&~0x0100));     // LOW:  Step forward  = to Spindl
    //
    *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0200);
    usleep( 10*1000 ); //
    *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0200);
    usleep( 10*1000 ); //
}
//
//
void WRITE_to_SD_Card1(void){
    //
    FILE    *fptr;
    int i=0;
    //
    fptr = fopen(myfile1, "wb");
    if(fptr == NULL) {
        printf ("\n\r\x07 ERROR open/write image file %s \n\r", myfile1);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    //
    //fwrite((void*)&MFMDISK.st_drive_c[i], 1 , 6400, fptr );
    fwrite((void*)&MFMDISK.st_drive_c[i], 1 , 10416, fptr );
    //
    fclose(fptr);
}
//
void WRITE_to_SD_Card2(void){
    //
    FILE    *fptr;
    int i=0;
    //
    fptr = fopen(myfile2, "wb");
    if(fptr == NULL) {
        printf ("\n\r\x07 ERROR open/write image file %s \n\r", myfile2);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    //
    fwrite((void*)&MFMDISK.st_drive_c[i], 1 , 41664, fptr );
    //
    fclose(fptr);
}
//
void WRITE_to_SD_Card3(void){
    //
    //#define track_size 5208          // One track size, 16Bit words
    FILE    *fptr;
    int i=0, diff , count=0;
    //
    fptr = fopen(myfile3, "wb");
    if(fptr == NULL) {
        printf ("\n\r\x07 ERROR open/write image file %s \n\r", myfile3);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    for ( i = 0; i < CYL_size*2 ; i++) {
        //printf ("\n\r Pattern: 0x%04X", MFMDISK.st_drive_i[i]);
        if((MFMDISK.st_drive_c[i] == DataAM_msb) & (MFMDISK.st_drive_c[i+1] == DataAM_lsb) ) {
            count++;
            printf ("\n\r found: DataAM_msb 0x%02X  DataAM_lsb 0x%02X  @ %d  Nr.: %d  Gap: %d", DataAM_msb, DataAM_lsb, i, count, i-diff);
            diff=i;
            fwrite((void*)&MFMDISK.st_drive_c[i+2], 1 , 512, fptr );
            i=i+SECsize+5;
        }
    }
    fclose(fptr);
}
//
void READ_drive_from_FPGA(int point_to_cylinder){
    //
    // FPGA Dual-Ported-RAM size: 4 x track size(5208) = 20830 16bit words/track
    // This routine reads one cylinder from FPGA/DP-RAM into union MFMDISK.st_drive_i
    //                               ####################
    //                               ### FPGA-->Union ###
    //                               ####################
    //
    mode = mode&~0x0010;                                // = READ from PORT A, bit05 = LOW
    *(uint32_t *)PIO_1_addr = mode;                     // SET
    //
    memcpy(&MFMDISK.st_drive_i[point_to_cylinder], (void *)(DPR_addr), CYL_size * 2);
    //
}
//
//
//
//
//                                            §§§§§§§§§§§§§§§§§§§§§§§§§§
//                                            §§§§§§§    MAIN    §§§§§§§
//                                            §§§§§§§§§§§§§§§§§§§§§§§§§§
//
int main()
{
    int steps, tocyl, trigger;
    int SDRAM_adress = 0;
    char buffer[10];
    char extension[6] = ".mfm";
    char extension3[6] = ".dsk";
    //
    FOUND   = 0;
    cl_mode = 0;
    mode    = 0;
    init_HW();
    *(uint32_t *)PIO_0_addr = mode;                     // Clear PIO-0
    *(uint32_t *)PIO_1_addr = mode;                     // Clear PIO-1
    *(uint32_t *)PIO_2_addr = cl_mode;                  // Clear PIO-2
    //
    while(priwhile == 0) {                              // Primary while
        //
        printf("\n\r\x1B[2J");
        printf("             ***** MFM-DISK   READER  @ Soc/HPS *****                  \n\r");
        printf("         READ one Cylinder/Track and save it to SD card                \n\r");
        printf("          DE10-Nano ST-506/412/225   Beta Version  V010                \n\r");
        printf("        ************************************************               \n\r");
        printf("              (c) Reinhard Heuberger WWW.PDP11GY.COM                   \n\r");
        //
        startup_leds();
        //
        // >>>>>>>>>>>>>>>>>> Check for debug mode <<<<<<<<<<<<
        if (( *(uint32_t *)PIO_2_addr) & 0x0040) {
           DEBUG = 1;
           printf ("\n\r              >>>>>> DEBUG-MODE = ON <<<<<<");
        } else {
           DEBUG = 0;
           printf ("\n\r              >>>>>> DEBUG-MODE = OFF <<<<<");
        }
        //
        //
        ST_type = ( *(uint32_t *)PIO_2_addr) &~0xFFF0;
        switch(ST_type) {
            case 0x0001:
                SDRAM = 6374400;
                MAXCYL = ST506_size;
                SECsize = 512;
                strcat( myfile1, "ST506-Track_head1_" );
                strcat( myfile2, "ST506-cylinder_" );
                strcat( myfile3, "ST506-Track-image_" );
                printf ("\n\r              >>>> Device Type = ST506 <<<<\n\r");
                DataAM = 0xA5F8;
                break;
            case 0x0002:
                SDRAM = 12774400;
                MAXCYL = ST412_size;
                SECsize = 512;
                strcat( myfile1, "ST412-Track_head1_" );
                strcat( myfile2, "ST412-cylinder_" );
                strcat( myfile3, "ST412-Track-image_" );
                printf ("\n\r              >>>> Device Type = ST412 <<<<\n\r");
                DataAM = 0xA5F8;
                break;
            case 0x0004:
                SDRAM = 25625600;
                MAXCYL = ST225_size;
                SECsize = 512;
                strcat( myfile1, "ST412-Track_head1_" );
                strcat( myfile1, "ST225-Track_head1_" );
                strcat( myfile2, "ST225-cylinder_" );
                strcat( myfile3, "ST225-Track-image_" );
                printf ("\n\r             >>>> Device Type = ST225 <<<<\n\r");
                DataAM = 0xA5F8;
                break;
            default:
                SDRAM = 12774400;
                MAXCYL = ST412_size;
                SECsize = 512;
                strcat( myfile1, "ST412-Track_head1_" );
                strcat( myfile2, "ST412-cylinder_" );
                strcat( myfile3, "ST412-Track-image_" );
                printf ("\n\r              ****     Using default   ****");
                printf ("\n\r              >>>> Device Type = ST412 <<<<\n\r");
                DataAM = 0xA5F8;
                break;
        }
        fflush(stdout);
        *(uint32_t *)PIO_3_addr = DataAM ;
        //
        //
        //
        //-----------------------------------------------------------------------------------------------------
        //
        printf("      ******************************************\n\r");
        printf("      **************** +Test-Mode **************\n\r");
        printf("      ******************************************\n\r");
        mode = 0x4001;                                                        // **********************
        *(uint32_t *)PIO_1_addr = mode;                                       // Disable Simulator mode
        //                                                                    // **********************
        //
        // Set Start-condition: CL_TRI_control
        cl_mode=0x8000;                                                       // Preset = Enable Clone mode
        *(uint32_t *)PIO_2_addr = cl_mode;                                    // Start conditions
        *(uint32_t *)PIO_1_addr = mode;                                       // ENABLE interface
        //
        if(DEBUG == TRUE) {
            printf("\n\r      Anzahl der Cylinder: %d ", MAXCYL );
        }
        //
        //---------------------------------------------------------------------+
        // First: find configured device number                                |
        //---------------------------------------------------------------------+
        FOUND = FALSE;
        if(FOUND == FALSE) {
            printf("\n\r      Drive_select #0 " );
            *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0010);   //#0
            usleep( 200*1000 );
            if (( *(uint32_t *)PIO_2_addr) & 0x1000) {
                printf(" DRV_SLCTD = HIGH " );
                FOUND=TRUE;
            }else{
                printf(" DRV_SLCTD = LOW  " );
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0010);
            }
        }
        // ------------------------------------------------------------------
        if(FOUND == FALSE) {
            printf("\n\r      Drive_select #1 " );
            *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0020);   //#1
            usleep( 200*1000 );
            if (( *(uint32_t *)PIO_2_addr) & 0x1000) {
                printf(" DRV_SLCTD = HIGH " );
                FOUND=TRUE;
            }else{
                printf(" DRV_SLCTD = LOW  " );
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0020);
            }
        }
        // ------------------------------------------------------------------
        if(FOUND == FALSE) {
            printf("\n\r      Drive_select #2 " );
            *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0040);   //#2
            usleep( 200*1000 );
            if (( *(uint32_t *)PIO_2_addr) & 0x1000) {
                printf(" DRV_SLCTD = HIGH " );
                FOUND=TRUE;
            }else{
                printf(" DRV_SLCTD = LOW  " );
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0040);
            }
        }
        // ------------------------------------------------------------------
        if(FOUND == FALSE) {
            printf("\n\r      Drive_select #3 " );
            *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0080);   //#3
            usleep( 200*1000 );
            if (( *(uint32_t *)PIO_2_addr) & 0x1000) {
                printf(" DRV_SLCTD = HIGH " );
                FOUND=TRUE;
            }else{
                printf(" DRV_SLCTD = LOW  " );
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0080);
            }
        }
        //
        usleep( 200*1000 );
        //-------------------------------------------------------------------
        if (FOUND == FALSE ){
            printf("\n\r\n      !!! ERROR:  NO disk found  !!! \n\r" );
            fflush(stdout);
            //while(1);
        }
        //-------------------------------------------------------------------
        if (( *(uint32_t *)PIO_2_addr) & 0x0100) {
            printf("\n\r      READY =      HIGH " );
        }else{
            printf("\n\r      READY =      LOW  " );
        }
        //-------------------------------------------------------------------
        if (( *(uint32_t *)PIO_2_addr) & 0x0800) {
            printf("\n\r      SEEK_cmplt = HIGH " );
        }else{
            printf("\n\r      SEEK_cmplt = LOW  " );
        }
        //-------------------------------------------------------------------
        if (( *(uint32_t *)PIO_2_addr) & 0x0400) {
          printf("\n\r      TRACK_0 =    HIGH " );
        }else{
          printf("\n\r      TRACK_0 =    LOW  " );
        }
        //-------------------------------------------------------------------
        if (( *(uint32_t *)PIO_2_addr) & 0x1000) {
          printf("\n\r      DRV_SLCTD =  HIGH " );
        }else{
          printf("\n\r      DRV_SLCTD =  LOW  " );
        }
        //
        //------------------------------------------------------------------+
        // Check for Drive READY @ CL_I[8] = 0x0100                         |
        //------------------------------------------------------------------+
        if (( *(uint32_t *)PIO_2_addr) & 0x0100) {
            printf("\n\r      Drive = ready" );
        }else{
            printf("\n\r Drive is NOT ready, wait ...." );
            while (!(*(uint32_t *)PIO_2_addr & 0x0400)) {
                usleep( 500*1000 );
                printf(".");
                fflush(stdout);
            }
            printf("\n\r      Drive = ready, continue" );
        }
        //
        //------------------------------------------------------------------+
        // Check & if necessary, adjust to home position @ CL_I[10]=0x0400  |
        //------------------------------------------------------------------+
        if (( *(uint32_t *)PIO_2_addr) & 0x0400) {
            printf("\n\r      Drive is @ home" );
            fflush(stdout);
        }else{
            printf("\n\r      Drive is NOT @ home" );
            fflush(stdout);
            *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0100);             // HIGH: Step backward = to Home
            while (!(*(uint32_t *)PIO_2_addr & 0x0400)) {                   // Step back, until
                stepping();                                                 // track0 signal receiving
            }
            printf("\n\r    Drive positioned to home" );
            fflush(stdout);
            *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0100);            // LOW:  Step forward  = to Spindl
        }
        printf("\n\r\n" );
        //
        //------------------------------------------------------------------+
        // Start collecting data                                            |
        //------------------------------------------------------------------+
        printf("\n\r       Cylinder - nummer eingeben:  ");
        scanf("%d", &tocyl);
        printf("\n\r       Trigger DataAM , (4Hex, like A5F8)  :");
        scanf("%4x", &trigger);
        DataAM = trigger;
        *(uint32_t *)PIO_3_addr = DataAM ;
        //
        DataAM_lsb = (unsigned)DataAM & 0xff;     // mask the lower 8 bits
        DataAM_msb = (unsigned)DataAM >> 8;       // shift the higher 8 bits
        //
        printf("\n\r   Cylinder: %d ,Trigger DataAM: lsb : 0x%02X  msb: 0x%2X  ", tocyl,DataAM_msb,DataAM_lsb );
        printf("\n\r\n      ************ Step to Cylinder %d ", tocyl);
        fflush(stdout);
        for(steps=0; steps<tocyl; steps++) {
            stepping();
            usleep( 1000 );
        }
        printf(" done ***********\n\r\n");
        fflush(stdout);
        //=====================================================================
        //
        *(uint32_t *)PIO_1_addr = (mode=mode|0x0008);                   // Disable  Clone_Enable
        //
        printf("\r         Select Head 1 ");fflush(stdout);
        *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0001);             // Set head #1
        usleep( 2*1000 );                                               // Wait a little ....
        *(uint32_t *)PIO_1_addr = (mode=mode&~0x0008);                  // Enable  Clone_Enabel
        usleep( 100*1000 );                                             // Delay to get one Track into DPR
        *(uint32_t *)PIO_1_addr = (mode=mode|0x0008);                   // Disable  Clone_Enable
        *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0001);            // Clear head #1
        usleep( 1000*1000 );                                               // Wait a little ....
        //
        printf("\r         Select Head 2 ");fflush(stdout);
        *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0002);             // Set head #2
        usleep( 2*1000 );                                               // Wait a little ....
        *(uint32_t *)PIO_1_addr = (mode=mode&~0x0008);                  // Enable  Clone_Enabel
        usleep( 100*1000 );                                             // Delay to get one Track into DPR
        *(uint32_t *)PIO_1_addr = (mode=mode|0x0008);                   // Disable  Clone_Enable
        *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0002);            // Clear head #2
        usleep( 1000*1000 );                                               // Wait a little ....
        //
        printf("\r         Select Head 3 ");fflush(stdout);
        *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0004);             // Set head #3
        usleep( 2*1000 );                                               // Wait a little ....
        *(uint32_t *)PIO_1_addr = (mode=mode&~0x0008);                  // Enable  Clone_Enabel
        usleep( 100*1000 );                                             // Delay to get one Track into DPR
        *(uint32_t *)PIO_1_addr = (mode=mode|0x0008);                   // Disable  Clone_Enable
        *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0004);            // Clear head #3
        usleep( 1000*1000 );                                               // Wait a little ....
        //
        printf("\r         Select Head 4 \r\n\n");fflush(stdout);
        *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0008);             // Set head #4
        usleep( 2*1000 );                                               // Wait a little ....
        *(uint32_t *)PIO_1_addr = (mode=mode&~0x0008);                  // Enable  Clone_Enabel
        usleep( 100*1000 );                                             // Delay to get one Track into DPR
        *(uint32_t *)PIO_1_addr = (mode=mode|0x0008);                   // Disable  Clone_Enable
        //*(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0008);          // Clear head #4
        //
        //
        //                                                              // ####################
        READ_drive_from_FPGA(SDRAM_adress);                             // ### FPGA-->Union ###
        //                                                              // ####################
        //
        //
        //
        //------------------------------------------------------------------+
        // Save data to Micro-SD-Card                                       |
        //------------------------------------------------------------------+
        sprintf(buffer, "%d", tocyl);
        strcat(myfile1, buffer);
        strcat(myfile2, buffer);
        strcat(myfile3, buffer);
        strcat(myfile1, extension);
        strcat(myfile2, extension);
        strcat(myfile3, extension3);
        //
        WRITE_to_SD_Card3();
        //
        printf ("\n\r      Save track@head1 data-image to SD-Card into file:  %s  \n\r", myfile3);
        printf ("\n\r      Save 1 cylinder data to SD-Card into file:  %s  \n\r", myfile2);
        //
        WRITE_to_SD_Card2();
        usleep( 2*1000 );
        //
        printf("\n\r      *********** Select Head 1 and loop **********\n\r"); fflush(stdout);
        *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0008);            // Clear head #4
        *(uint32_t *)PIO_1_addr = (mode=mode|0x0008);                   // Disable  Clone_Enable
        *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0001);             // Set head #1
        usleep( 2*1000 );                                               // Wait a little ....
        *(uint32_t *)PIO_1_addr = (mode=mode&~0x0008);                  // Enable  Clone_Enabel
        printf ("\n\r      Save 1 track@head1 data to SD-Card into file:  %s  \n\r", myfile1);
        //
        //                                                              // ####################
        READ_drive_from_FPGA(SDRAM_adress);                             // ### FPGA-->Union ###
        //                                                              // ####################
        //
        WRITE_to_SD_Card1();
        //
        //
        //----------------------------------------------------------------------------------------------------------------------
        while ( ~ *(uint32_t *)PIO_1_addr & 0x8000 );   // Reset/Exit,       = Button 1 released
        usleep( 500*1000 );
        while ( ~ *(uint32_t *)PIO_1_addr & 0x4000 );   // Reconfig/Restart, = Button 2 released
        usleep( 500*1000 );
        printf("\x07\n\n\r  Press RESET/Button-1 for exit, Reconfig/Button-2 for restart  \n\r");
        priwhile = 2;
        while(priwhile == 2) {
            if ( ~ *(uint32_t *)PIO_1_addr & 0x4000 ) {  // Reconfig/Restart
                usleep( 500*1000 );
                secwhile = 0;
                priwhile = 0;
            }
            if ( ~ *(uint32_t *)PIO_1_addr & 0x8000 ) {  // Reset/EXit
                printf("\x07\n\n\r    Servus & Bye\n\r\n");
                fflush(stdout);
                usleep( 500*1000 );
                secwhile = 1;
                priwhile = 1;
            }
        }
    } // Primary while
    return 0;
}