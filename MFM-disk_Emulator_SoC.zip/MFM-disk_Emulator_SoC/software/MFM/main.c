/*
              *****************************************************************************
              *  Copyright (C)  by Reinhard Heuberger   www.pdp11gy.com                   *
              *                                                                           *
              *  All rights reserved.                                                     *
              *                                                                           *
              *  Redistribution and use in source and binary forms, with or without       *
              *  modification, are permitted provided that the following conditions       *
              *  are met:                                                                 *
              *                                                                           *
              *  1. Redistributions of source code must retain the above copyright        *
              *     notice, this list of conditions and the following disclaimer.         *
              *  2. Redistributions in binary form must reproduce the above copyright     *
              *     notice, this list of conditions and the following disclaimer in the   *
              *     documentation and/or other materials provided with the distribution.  *
              *  3. Neither the name of the author nor the names of its contributors may  *
              *     be used to endorse or promote products derived from this software     *
              *     without specific prior written permission.                            *
              *                                                                           *
              *****************************************************************************

                              MFM-DISK clone/emulator ST506/412/225
                           Version V.1.0 for SoC HPS FPGA-environment
						 Beta Version V010  for SoC HPS FPGA-environment
                                    ( Quartus Version 16.1 )
                                    based on DE10-Nano Board
                           by: Reinhard Heuberger , www.PDP11GY.com
                   https://github.com/pdp11gy/SoC-HPS-based-MFM-disk-emulator


                                 Data - Structure and Mapping:

                         |<-32 MB  SD RAM ->|      |<- DP-RAM-->|

              / 5.898240 +------------------+
             /           |   Cylinder #306  |      +------------+ 20832
   +--------+   5.886720 +------------------+     /|  Track #3  |>15624-20831
   |        |            |                  |    / |- - - - - - | 15624
   |   SD   |            .                  .   /  |  Track #2  |>10416-15623
   |  CARD  |            .                  .  /   |- - - - - - | 10416
   |        |            |                  | /    |  Track #1  |>05208-10415
   +--------+     20832  +------------------+/     |- - - - - - | 05208
             \           |    Cylinder #0   |      |  Track #0  |>00000-05207
              \   00000  +------------------+ - - -+------------+ 00000

       The ST506/412/225 disk drive did have a capacity of 6.38/12.76/20.0MB
                        ST506 = 153 cylinder ,  612 tracks
                        ST412 = 306 cylinder , 1224 tracks
                        ST225 = 615 cylinder , 2460 tracks
                                 32 sectors / track

        Nominal Track Capacity:           =    10416 ( Byte )
        Setzt sich wie folgt zusammen:

        Total Data Bytes/Track = 256   x 32 =     8192
        SYNC = 13x00           =  13   x 32 =      416
        ID AM = 2 Byte         =   2   x 32 =       64
        CYL/HD/SEC = 3 Byte    =   3   x 32 =       96
        Header-CRC = 2 Byte    =   2   x 32 =       64
        Gap2 3 + 13 = 16Byte   =  16   x 32 =      512
        Data AM = 2 Byte       =   2   x 32 =       64
        Data-CRC = 2 Byte      =   2   x 32 =       64
        Gap3 1of2 = 3x00       =   3   x 32 =       96
        Gap3 2of2 = 15x4E      =  15   x 32 =      480
                               ------------------------+-----------------
                         SECTOR: 314      TRACK: 10048 |  CYLINDER: 40192
        Einmalig dazu:   Gap1  16x4E      =         16 |               64
                         Gap4 352x4E      =        352 |             1408
                                       ----------------+-----------------
                             ( Byte )            10416 |            41664
                              ( Bit )            83328 |           333312
                             ( Word )             5208 |            20832
                             ==========================+=================

    APR-2019: Switched to Byte-mode ( Little/Big endian mode is no longer necessarry )

*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include "hwlib.h"
#include "socal/socal.h"
#include "socal/hps.h"
#include "socal/alt_gpio.h"
#include "hps_0.h"
#include <signal.h>
//
//
void init_HW(void);
void startup_leds(void);
void print_binary_16bit_LSB( unsigned short ibit16);
void PRESET_one_SECTOR(void);
void make_header_CRC(void);
void make_data_CRC(void);
void make_full_ST(void);
void make_bootsector(void);
void WRITE_drive_to_FPGA(int point_to_cylinder);
void READ_drive_from_FPGA(int point_to_cylinder);
void acknowledge(void);
void WRITE_to_SD_Card(void);
void READ_from_SD_Card(void);
void stepping(void);
void make_myfile_on_SD_Card(void);
void WRITE_to_SD_Card(void);
void WRITE_to_SD_Card3(void);
void READ_from_SD_Card(void);
//
//
typedef unsigned char byte;
//
#define HW_REGS_BASE ( ALT_STM_OFST )             // axi_lw
#define HW_REGS_SPAN ( 0x04000000 )               // Bridge span
#define HW_REGS_MASK ( HW_REGS_SPAN - 1 )
#define ALT_AXI_FPGASLVS_OFST (0xC0000000)        // axi_master
#define HW_FPGA_AXI_SPAN (0x40000000)             // Bridge span
#define HW_FPGA_AXI_MASK ( HW_FPGA_AXI_SPAN - 1 )
//
#define CYL_size 20832           // One cylinder size, 16Bit words
#define DPR_size 20832           // Dual-Portet-RAM size, 16Bit words
#define track_size 5208          // One track size, 16Bit words
#define ST506_size 153           // ST506 = 153 cylinder (  5.40 MB )
#define ST412_size 306           // ST412 = 306 cylinder ( 10.16 MB )
#define ST225_size 615           // ST225 = 615 Cylinder ( 20.42 MB )
#define TRUE  1
#define FALSE 0
//
unsigned short int header_index =   7;                             // Header index = 7 (word) (15=byte)
unsigned short int data_start =    19;                             // + 12
unsigned short int data_CRC =     147;                             //    + 128
unsigned short int ST_unit  =       0;                             // current selected ST unit-number
unsigned short int ST_type  =       0;                             // Drive-Type
unsigned short int CYL_P = 15, HD_P = 17, SEC_P = 16;              // point to cylinder,head, sector
unsigned short int DataAM = 0xA5F8;                                // !!! Indicator Pattern before Data Field !!!
unsigned char DataAM_lsb, DataAM_msb;                              //  split in 2 bytes
//
short int mode=0;                                                  // System operating mode >general
short int cl_mode=0;                                               // System operating mode >clone-mode
unsigned char FOUND=0;                                             // drive found , clone mode
unsigned char DEBUG=0;                                             // DEBUG PURPOSE
unsigned char OFFLINE=0;                                           // online/offline mode
unsigned char OFFMODE=0;                                           // full/simple offline mode
//
/*        *********************** Global Definitions **********************        */
//
//++++++++++++++++++++++++++++++++++ UNION's +++++++++++++++++++++++++++++++++++++++++++++++++++++++++
union std {                                  // ****** ST-506/412 sector ************
       unsigned char  st_c[512];             // Access to one sector via 314 bytes or
       unsigned short st_i[256];             // 157 16Bit words  , alligned to 512/256
       unsigned int   st_l[128];
};
//union  std SECTOR;                                               // define a union of type SECTOR
union  std SECTOR __attribute__ ((aligned(4)));                    // define a union of type SECTOR
union  std *u_stptr;                                               // pointer to union.
//
//
//                     ****** ST-412/506 u. ST225 @ SD-RAM/=union ********
//                     Virtual access to 306 cylinders(head 0 to 3)
//                     4heads: = 1cylinder = 20832 16 bit * 306 = 6374592 = 12749184 Byte
//                     Alligned to 12774400 = 24950 Blocks @ SD-CArd
//                     --Now with ST225 Support:
//                       20832 16 bit * 615 = 12811680 = 25623360 Byte
//                       Alligned to 25625600  = 50050 Blocks @ SD-CArd
union mfm {
       unsigned char  st_drive_c[25625600];    //ST225=12774400
       unsigned short st_drive_i[12812800];    //ST412=6387200
       unsigned int   st_drive_l[6406400];     //ST506=3193600
};
//union  mfm MFMDISK;                                              // define a union of type MFMDISK
union  mfm MFMDISK __attribute__ ((aligned(4)));                   // define a union of type MFMDISK
union  mfm *u_st_drive_ptr;                                        // pointer to union
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//
int SDRAM                   = 12748800;                            // maximum used bytes SD-RAM
int SECsize                 = 512;                                 // Sector size , Byte
unsigned short MAXCYL       = 306;                                 // cylinder, ST412/ST506
//
// strcat( myfile2, "ST412_0.STD" ) "ST412_0.STD";
char myfile2[80];
char myfile1[80];
char myfile3[80];
//
//------------------------------------------------------------------------------------------------------
int fd;                                           // Hold FPGA address
void *virtual_base;                               // Virtual axi-lw addr that maps to physical
void *axi_virtual_base;                           // Virtual axi-master addr that maps to physical
void *PIO_0_addr;                                 // PIO-0 address
void *PIO_1_addr;                                 // PIO-1 address
void *PIO_2_addr;
void *PIO_3_addr;
void *DPR;                                        // #1, Dual Ported Ram address
void *DPR_addr;                                   // #1, Dual Ported Ram address with AXI-Master
//void *XDPR;                                     // #2, Dual Ported Ram address
//void *XDPR_addr;                                // #2, Dual Ported Ram address with AXI-Master
void *UART0;                                      // UART_0 address
//------------------------------------------------------------------------------------------------------
//
unsigned char priwhile = 0;
unsigned char secwhile = 0;
//
//
//
void init_HW(void)
{
  //---------------------------------------------------------------------------------------------------
  // === get FPGA addresses ===
  // Open /dev/mem
  if( ( fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
        printf( "ERROR: could not open \"/dev/mem\"...\n" );
  return; }
  //---------------------------------------------------------------------------------------------------
  // Get virtual addr that maps to physical
  virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );
  if( virtual_base == MAP_FAILED ) {
        printf( "ERROR: mmap() failed...\n" );
        close( fd );
  return; }
  axi_virtual_base = mmap( NULL, HW_FPGA_AXI_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, ALT_AXI_FPGASLVS_OFST );
  //----------------------------------------------------------------------------------------------------
  //
  // Get the addresses that maps to the FPGA control 
  PIO_0_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + PIO_0_BASE ) 
                                & ( unsigned long)( HW_REGS_MASK ) );
  PIO_1_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + PIO_1_BASE ) 
                                & ( unsigned long)( HW_REGS_MASK ) );
  PIO_2_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + PIO_2_BASE ) 
                                & ( unsigned long)( HW_REGS_MASK ) );
  PIO_3_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + PIO_3_BASE ) 
                                & ( unsigned long)( HW_REGS_MASK ) );                               
  DPR =  virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + DPR_BASE )
                      & ( unsigned long)( HW_REGS_MASK ) ); 
  DPR_addr =   axi_virtual_base + ( ( unsigned long  )( DPR_BASE ));
/*
  XDPR =  virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + XDPR_BASE )
                      & ( unsigned long)( HW_REGS_MASK ) ); 
  XDPR_addr =   axi_virtual_base + ( ( unsigned long  )( XDPR_BASE ));
*/  
  UART0 = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + UART_0_BASE )
                      & ( unsigned long)( HW_REGS_MASK ) ); 
  if( virtual_base == MAP_FAILED ) {
        printf( "ERROR: mmap() failed...\n" );
        close( fd );
        return; 
  }
  //-----------------------------------------------------------------------------------------------------
  // 
}
//
//
void startup_leds(void)
{
int loop_count;
int led_direction;
int led_mask;
loop_count = 0;
led_mask = 0x01;
led_direction = 0; // 0: left to right direction
    //
    while(loop_count < 3 )  {
      *(uint32_t *)PIO_0_addr = led_mask;
      usleep( 20*1000 );
      if (led_direction == 0){
            led_mask <<= 1;
            if (led_mask == (0x01 << (PIO_0_DATA_WIDTH-1)))
                 led_direction = 1;
        }else{
            led_mask >>= 1;
            if (led_mask == 0x01){ 
                led_direction = 0;
                loop_count++;
            }
        }        
    }
}
//
//
void print_binary_16bit_LSB( unsigned short ibit16)
// Representation: LSB on right site ( PDP-11 like)
{
 int i;
  for (i = 0; i < 16; i++ ){
       if(0x8000 & ibit16 ) {               // Test Bit 15
          printf("1");
          }
           else {
              printf("0");
           }
   ibit16 = ibit16 << 1;
  }
}
//
//
//- calcCRC16r ------------------------------------------------------
unsigned short int calcCRC16r(unsigned short int crc, unsigned short int c, unsigned short int mask)
//
// Note: This smart C-Code was not written by myself.
// Reference: http://www.mikrocontroller.net/topic/12177#2274632
{
  unsigned char i;
  for(i=0;i<8;i++)
  {
    if((crc ^ c) & 1) { crc=(crc>>1)^mask; }
    //if((crc = crc  ^ c) & 1) { crc=(crc>>1)^mask; }
    else crc>>=1;
    c>>=1;
  }
  return (crc);
}
//
//
void PRESET_one_SECTOR(void) {
  // +
  // initialize data for one sector used for test and reference purpose.
  // Without Gap1 & Gap4 = 314 Byte , 0 - 313
  // -
  int i;
  header_index = 7;                                                  //   7  **** Set ****
  data_start = header_index + 12;                                    //  19  **** Set ****
  data_CRC = data_start + 128;                                       // 147  **** Set ****
  CYL_P = 15; HD_P = 16; SEC_P = 17;
  //
  unsigned short mysector[]=
  { 0x0000, 0x0000, 0x0000, 0x0000,                                  //  SYNC 0-3(0-7)
    0x0000, 0x0000,                                                  //  SYNC 4-5(8-11)
    0xA100,                                                          //  6= ( SYNC(12), IDAM,1of2(13) )
    //
    0x00FE,                                                          //  7= ( IDAM,2of2(14), CYL(15)<-)
    0x0000,                                                          //  8= ( HD(16), SEC(17) )
    0x0000,                                                          //  9= Header-CRC(18-19)
    //
    0x0000, 0x0000, 0x0000, 0x0000,                                  //  Gap 2 10-13(20-27)
    0x0000, 0x0000, 0x0000, 0x0000,                                  //  Gap 2 14-17(28-35)
    0xF8A1,                                                          //  18= AM(36-37)
    //                                  DATA 19-147(38-293)
    0x0000, 0x0000,                                                   //  Data 00-01
    0xFF00, 0xFF00, 0xFF00, 0xFF00, 0xFF00, 0x0000, 0x0000, 0x0000,   //  Data 02-09
    0x3333, 0x3333, 0x3333, 0x3333, 0x3333, 0x0000, 0x0000, 0x5500,   //  Data 10-17
    0x5555, 0x5555, 0x5555, 0x5555, 0x0055, 0x0000, 0x0000, 0x9249,   //  Data 18-25
    0x4924, 0x2492, 0x9249, 0x0024, 0x0000, 0x0000, 0x9123, 0x23DC,   //  Data 26-33
    0xDC91, 0x9123, 0x00DC, 0x0000, 0x0000, 0x8080, 0x8080, 0x8080,   //  Data 34-41
    0x8080, 0x8080, 0x0000, 0x0000, 0xE700, 0xF39C, 0x9CE7, 0xE7F3,   //  Data 42-49
    0xF39C, 0x0000, 0x0000, 0x6300, 0xF18C, 0x8C63, 0x63F1, 0xF18C,   //  Data 50-57
    0x0000, 0x0000, 0x7F00, 0x7F7F, 0x7F7F, 0x7F7F, 0x7F7F, 0x007F,   //  Data 58-65
    0x0000, 0x0000, 0x0D0A, 0x464D, 0x2D4D, 0x5320, 0x4D49, 0x4C55,   //  Data 66-73
    0x5441, 0x524F, 0x5620, 0x4E4F, 0x5220, 0x4945, 0x484E, 0x5241,   //  Data 74-81
    0x2044, 0x4548, 0x4255, 0x5245, 0x4547, 0x0A52, 0x4D0D, 0x4D46,   //  Data 82-89
    0x202D, 0x4953, 0x554D, 0x414C, 0x4F54, 0x2052, 0x4F56, 0x204E,   //  Data 90-97
    0x4552, 0x4E49, 0x4148, 0x4452, 0x4820, 0x5545, 0x4542, 0x4752,   //  Data 98-105
    0x5245, 0x0D0A, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF,   //  Data 106-113
    0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF,   //  Data 114-121
    0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x0000,                   //  Data 122-127
    0x3A33,                                                           //  147= Data 128 = CRC
    //
    0x0000, 0x4E00, 0x4E4E, 0x4E4E,                                   //  148-151 = Gap 3
    0x4E4E, 0x4E4E, 0x4E4E, 0x4E4E, 0x4E4E,                           //  152-156 = Gap 3
    0x0000, 0x0000, 0x0000, 0x0000 };                                 //  157-160 = ** Dummy,END of Data **
    //
    //
    for (i = 0; i < 256; i++ ){ SECTOR.st_i[i] = 0x0000; }           // clear buffer
    for (i = 0; i < 160; i++ ){ SECTOR.st_i[i] = mysector[i]; }      // Load buffer
    make_data_CRC();
    //printf("\n\r Data-CRC 0X3A33 calculated : %#X \n",SECTOR.st_i[data_CRC]);
    //print_sector();
    SECTOR.st_l[100]=0x2E575757; // "WWW."
    SECTOR.st_l[101]=0x31504450; // "PDP1"
    SECTOR.st_l[102]=0x2E594731; // "1GY."
    SECTOR.st_l[103]=0x204D4F43; // "COM "
    SECTOR.st_l[127]=0x45444E45; // "ENDE" = Indicator
}
//
//
void make_header_CRC(void){
  unsigned short int DEVICE_CRC16;
  //
  DEVICE_CRC16 = 0;                             // preset Data-CRC
  //DEVICE_CRC16 = 0xFFFF;                      // preset Data-CRC
  //
  /*
  // Header - Word 1 of 3  ( data )
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.st_c[header_index*2],0xA001);   //HSB
  //DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.st_c[header_index*2+1],0xA001); //LSB
  // Header - Word 2 of 3
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.st_c[header_index*2+2],0xA001); //HSB
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.st_c[header_index*2+3],0xA001); //LSB
  // Header - Word 3 of 3  -> Header-CRC
  SECTOR.st_i[header_index+2]=DEVICE_CRC16;  //Save CRC
  */
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.st_c[CYL_P],0xA001);  //MSB
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.st_c[HD_P],0xA001);   //LSB
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.st_c[SEC_P],0xA001);  //MSB
  // Header - Word 3 of 3  -> Header-CRC
  SECTOR.st_i[header_index+2]=DEVICE_CRC16;  //Save CRC
}
//
//
void make_data_CRC(void){
  unsigned short int i, MSB, LSB;
  unsigned short int DEVICE_CRC16;
  //
  DEVICE_CRC16 = 0;                                    // preset Data-CRC
  //DEVICE_CRC16 = 0xFFFF;                             // preset Data-CRC
  //
  for (i = (data_start); i < (data_CRC); i++ ){
    MSB = i<<1;
    LSB = MSB + 1;
    DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.st_c[MSB],0xA001);
    DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.st_c[LSB],0xA001);
  }
  SECTOR.st_i[data_CRC] = DEVICE_CRC16;       // SET DATA-CRC
}
/*
                         HEADER representation (LSB first)
          15                          8 7                          0
           +---------------------------+---------------------------+
   word#7  |     (15)CYLINDER          |  (14)IDAM(byte 2of2)=FE   |
           +---------------------------+---------------------------+
   word#8  |      (17)SECTOR           |7|6|5|    (16)HEAD         |
           +---------------------------+---------------------------+
   word#9  |                      HEADER  CRC                      |
           +-------------------------------------------------------+
   Note:
   Bit 5 of Head Byte reserved for numbering cylinder greater than 256
   Bit 6 of Head Byte reserved for numbering cylinder greater than 512
   Bit 7 of Head Byte ID Field equals 1 in a defective sector ( not used,=0 )

*/
void make_full_ST(void) {
    // +
    // construct full ST-disk image in Memory ( union = SD RAM ). The idea behind this
    // routine is to dump the memory contents in pieces of 512 byte to the SD-Card after
    // constructing the ST-disk image in Memory.
    // -
    unsigned short int ST_cylinder, ST_track, ST_sector;
    int SDRAM=0, i, j;
    unsigned char head = 0, cyl = 0;
    //
    unsigned char interleave[]=
        { 0,8,16,24,1,9,17,25,2,10.18,26,3,11,19,27,
          4,12,20.28,5,13,21,29,6,14,22,30,7,15,23,31};
    //
    //
    for (ST_cylinder = 0; ST_cylinder < MAXCYL; ST_cylinder++ ) {                // ** 153(ST506)/306(ST412) Cylinder
        //
        head = 1;
        for (ST_track = 0; ST_track < 4; ST_track++ ) {                            // ** 4 Tracks(heads) +
            //
            for ( i = SDRAM; i < SDRAM+16 ; i++) {
                MFMDISK.st_drive_c[i] = 0x4E; 
            }                                                                     // A) Make Gap 1
            SDRAM = SDRAM + 16;
            //
            for (ST_sector = 0; ST_sector < 32; ST_sector++ ) {                                // ** 32 Sectors +
                SECTOR.st_c[HD_P]    = head;                                                   // SET Head
                SECTOR.st_c[SEC_P]   = interleave[ST_sector];                                  // SET Sector
                SECTOR.st_c[CYL_P]   = (ST_cylinder & 0xff);                                   // set cylinder bit 0-7
                SECTOR.st_c[HD_P] = SECTOR.st_c[HD_P] | (((ST_cylinder & 0x0300)>>3) & 0xff);  // bit 8+9
                make_header_CRC();
                //
                j=0;
                for(i = SDRAM; i< SDRAM+314; i++) {
                    MFMDISK.st_drive_c[i] = SECTOR.st_c[j];                      // Copy sector into RAM
                    j++;
                }
            SDRAM = SDRAM + 314;
            }                                                                    // ** 32 Sectors -
            for ( i = SDRAM; i < SDRAM+352 ; i++) {                              // B) Make Gap 4
                MFMDISK.st_drive_c[i] = 0x4E; 
            }
            SDRAM = SDRAM + 352;
            head = head <<1;                                                     // next head
        }                                                                        // ** 4 Tracks(heads) -
        //
        cyl++;
        //printf("\n\r  Cylinder: %d    SDRAM: %d", cyl, SDRAM );
    }                                                                            // ** 306 Cylinder -
    make_bootsector();
}
//
//
void make_bootsector(void) {
    //+
    //Only useful in a DEC environment
    //-
    short int i, data_begin;
    unsigned short bootsector[]=
    { 0x00A0, 0x0005, 0x0104, 0x0000, 0x0000, 0x4310, 0x9C10, 0x0100,        // * ..........C....*
      0x0837, 0x0024, 0x000D, 0x0000, 0x0A00, 0x423F, 0x4F4F, 0x2D54,        // *7.$.......?BOOT-*
      0x2D55, 0x6F4E, 0x6220, 0x6F6F, 0x2074, 0x6E6F, 0x7620, 0x6C6F,        // *U-No boot on vol*
      0x6D75, 0x0D65, 0x0A0A, 0x0080, 0x8BDF, 0xFF74, 0x80FD, 0x941F,        // *ume....._.t.}...*
      0xFF76, 0x80FA, 0x01FF, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000 };      // *v.z.............*
    //
    data_begin = data_start/2;                                               // byte to 16bit word
    for (i = data_begin; i < data_begin+128; i++ )
        { SECTOR.st_i[i] = 0x0000; }                                         // clear data area
    for (i = 0; i < 40; i++){
        SECTOR.st_i[i+data_begin] = bootsector[i];                           // init Sector
    }
    make_data_CRC();                                                         // -->CRC
    for (i = data_begin; i < data_begin+128; i++ ){                          // Copy sector into RAM
        MFMDISK.st_drive_i[i+8] = SECTOR.st_i[i];                            // Gap1 End = @16, = 8words
    }
    //printf ("\n\r   Boot sector done \n\r ");
}
//
//
void WRITE_drive_to_FPGA(int point_to_cylinder){
    //
    // FPGA Dual-Ported-RAM size: 4 x track size(5208) = 20830 16bit words/track
    // This routine writes one cylinder from union MFMDISK.st_drive_i to FPGA/DP-RAM
    //                               ####################
    //                               ### Union-->FPGA ###
    //                               ####################
    //
    mode = mode|0x0010;                                 // = WRITE to PORT A, bit05 = HIGH
    *(uint32_t *)PIO_1_addr = mode;                     // SET
    //
    memcpy((void *)(DPR_addr), &MFMDISK.st_drive_i[point_to_cylinder], CYL_size * 2);
    //
    mode = mode&~0x0010;                                // = READ from  PORT A, bit05 = LOW
    *(uint32_t *)PIO_1_addr = mode;                     // SET
}
//
//
void READ_drive_from_FPGA(int point_to_cylinder){
    //
    // FPGA Dual-Ported-RAM size: 4 x track size(5208) = 20830 16bit words/track
    // This routine reads one cylinder from FPGA/DP-RAM into union MFMDISK.st_drive_i
    //                               ####################
    //                               ### FPGA-->Union ###
    //                               ####################
    //
    mode = mode&~0x0010;                                // = READ from PORT A, bit05 = LOW
    *(uint32_t *)PIO_1_addr = mode;                     // SET
    //
    memcpy(&MFMDISK.st_drive_i[point_to_cylinder], (void *)(DPR_addr), CYL_size * 2);
    //
}
//
//
void acknowledge(void){
  // Terminate Seek-cycle,  sending a acknowledge pulse  @ O_ctrl[2]
  *(uint32_t *)PIO_1_addr = (mode=mode|0x0004);                     // Set Acknowledge
  usleep( 1000 );
  *(uint32_t *)PIO_1_addr = (mode=mode&~0x0004);                    // Clear Acknowledge
}
//
//
void stepping(void){
    //
    // Generate 1 Step puls. Note:
    //IOWR_ALTERA_AVALON_PIO_DATA(PIO_2_BASE, (cl_mode=cl_mode|0x0100));      // HIGH: Step backward = to Home
    //IOWR_ALTERA_AVALON_PIO_DATA(PIO_2_BASE, (cl_mode=cl_mode&~0x0100));     // LOW:  Step forward  = to Spindl
    //
    *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0200);
    usleep( 10*1000 ); // 
    *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0200);
    usleep( 10*1000 ); //
}
//
//
void make_myfile_on_SD_Card(void){
  FILE    *fptr;
  //
  fptr = fopen(myfile1, "w");
  if(fptr == NULL) {
    printf ("\n\r\x07 ERROR open/write file %s \n\r", myfile1);
    while(1); }
  fprintf(fptr,"         SOC/HPC based V 1.0 MFM disk emulator    \r\n");
  fprintf(fptr,"          developed with Quartus Version 16.1     \r\n");
  fprintf(fptr,"         Copyright (C) by Reinhard Heuberger\r\n");
  fprintf(fptr,"          www.pdp11gy.com  info@pdp11gy.com\r\n");
  fclose(fptr);
  //
}
//
//
void WRITE_to_SD_Card(void){
    //
    // ST506: 5,62 MB ( 5.898.752 Bytes)
    // ST412: 12,1 MB (12.750.848 Bytes)
    //
    //int *my_BUFFER = (void*)&RLDRIVE.rl_drive_c[0];
    //printf(" size:  %d \n\r", (int)sizeof(RLDRIVE.rl_drive_c) );
    //
    FILE    *fptr;
    int loops=SDRAM/25600, i=0, j=0;
    //
    fptr = fopen(myfile2, "wb");
    if(fptr == NULL) {
        printf ("\n\r\x07 ERROR open/write image file %s \n\r", myfile2);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    for(j=0; j<loops; j++) {
        fwrite((void*)&MFMDISK.st_drive_c[i], 1 , 25600, fptr );
        i=i+25600;
    }
    fwrite((void*)&SECTOR.st_c[0], 1, 512, fptr );
    //
    fclose(fptr);   
}
//
void WRITE_to_SD_Card3(void){
    //
    //#define track_size 5208          // One track size, 16Bit words
    FILE    *fptr;
    int i=0;
    //
	//printf("\n\r   Trigger DataAM: lsb : 0x%02X  msb: 0x%2X  ",DataAM_msb,DataAM_lsb );
    fptr = fopen(myfile3, "wb");
    if(fptr == NULL) {
        printf ("\n\r\x07 ERROR open/write image file %s \n\r", myfile3);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    for ( i = 0; i < ((CYL_size*2) * MAXCYL); i++) {   
        if((MFMDISK.st_drive_c[i] == DataAM_msb) & (MFMDISK.st_drive_c[i+1] == DataAM_lsb) ) {
            fwrite((void*)&MFMDISK.st_drive_c[i+2], 1 , SECsize , fptr );
            i=i+SECsize+5;
        }   
    }   
    fclose(fptr);   
}
//
void READ_from_SD_Card(void){
    //
    // ST506: 5,62 MB ( 5.898.752 Bytes)
    // ST412: 12,1 MB (12.750.848 Bytes)
    //
    //int *my_BUFFER = (void*)&RLDRIVE.rl_drive_c[0];
    //printf(" size:  %d \n\r", (int)sizeof(RLDRIVE.rl_drive_c) )
    //
    FILE    *infile = 0;
    int loops=SDRAM/25600, i=0, j=0;
    //
    infile = fopen(myfile2, "rb");
    if(infile == NULL) {
        printf ("\n\n\n\r\x07 ERROR open/read image .DSK file %s \n\r", myfile2);
        printf ("FIX THIS PROBLEM AND RESTART");
        fflush(stdout);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    for(j=0; j<loops; j++) {
        fread ((void*)&MFMDISK.st_drive_c[i], 1 , 25600, infile );
        i=i+25600;
    }  
    fread((void*)&MFMDISK.st_drive_c[0], 1, 512, infile );
    fclose(infile);  
}
//
//
//
//
//                                            §§§§§§§§§§§§§§§§§§§§§§§§§§
//                                            §§§§§§§    MAIN    §§§§§§§
//                                            §§§§§§§§§§§§§§§§§§§§§§§§§§
//
int main()
{   
    int steps;
    int SDRAM_adress = 0;
    unsigned short int cylinder;
    strcpy( myfile1, "PDP11GY.INF" );
    //
    FOUND   = 0;
    cl_mode = 0;
    mode    = 0;
    init_HW();
    *(uint32_t *)PIO_0_addr = mode;                     // Clear PIO-0
    *(uint32_t *)PIO_1_addr = mode;                     // Clear PIO-1
    *(uint32_t *)PIO_2_addr = cl_mode;                  // Clear PIO-2
    //
    while(priwhile == 0) {                              // Primary while
        //
        printf("\n\r\x1B[2J");
        printf("             ***** MFM-DISK EMMULATOR @ Soc/HPS *****                  \n\r");
        printf("        DE10-Nano ST-506/412/225 Simulator Version V.1.0               \n\r");
        printf("        ************************************************               \n\r");
        printf("              (c) Reinhard Heuberger WWW.PDP11GY.COM             \n\r");
        //
        startup_leds();
        PRESET_one_SECTOR();
        //
        // >>>>>>>>>>>>>>>>>> Check for debug mode <<<<<<<<<<<<
        if (( *(uint32_t *)PIO_2_addr) & 0x0040) {
           DEBUG = 1;
           printf ("\n\r              >>>>>> DEBUG-MODE = ON <<<<<<");
        } else {
           DEBUG = 0;
           printf ("\n\r              >>>>>> DEBUG-MODE = OFF <<<<<");
        }
        //
        //
        ST_type = ( *(uint32_t *)PIO_2_addr) &~0xFFF0;
        switch(ST_type) {
            case 0x0001:
                SDRAM   = 6374400;
                MAXCYL  = ST506_size;
                SECsize = 512;
                strcat( myfile2, "ST506.mfm" );
                strcat( myfile3, "ST506-image.img" );
                printf ("\n\r              >>>> Device Type = ST506 <<<<\n\r");
                DataAM = 0xA5F8;
                break;
            case 0x0002:
                SDRAM   = 12774400;
                MAXCYL  = ST412_size;
                SECsize = 512;
                strcat( myfile2, "ST412.mfm" );
                strcat( myfile3, "ST412-image.img" );
                printf ("\n\r              >>>> Device Type = ST412 <<<<\n\r");
                DataAM = 0xA5F8;
                break;
            case 0x0004:
                SDRAM   = 25625600;
                MAXCYL  = ST225_size;
                SECsize = 512;
                strcat( myfile2, "ST225.mfm" );
                strcat( myfile3, "ST225-image.img" );
                printf ("\n\r             >>>> Device Type = ST225 <<<<\n\r");
                DataAM = 0xA5F8;
                break;
            default:
                SDRAM   = 12774400;
                MAXCYL  = ST412_size;
                SECsize = 512;
                strcat( myfile2, "default-ST412.mfm" );
                strcat( myfile3, "default-ST412-image.img" );
                printf ("\n\r              ****     Using default   ****");
                printf ("\n\r              >>>> Device Type = ST412 <<<<\n\r");
                DataAM = 0xA5F8;
                break;          
        }
        fflush(stdout);
        DataAM_lsb = (unsigned)DataAM & 0xff;     // mask the lower 8 bits
        DataAM_msb = (unsigned)DataAM >> 8;       // shift the higher 8 bits
        *(uint32_t *)PIO_3_addr = DataAM ;        // Send DataAM to MFM decoder
        //
        //      
        //      
        if (( *(uint32_t *)PIO_1_addr) & 0x0020) {
            //
            printf("      ******************************************\n\r");
            printf("      **************** Clone-Mode **************\n\r");
            printf("      ******************************************\n\r");
            mode = 0x4001;                                                        // **********************
            *(uint32_t *)PIO_1_addr = mode;                                       // Disable Simulator mode
            //                                                                    // **********************
            //                                                                                                                                        
            // Set Start-condition: CL_TRI_control
            cl_mode=0x8000;                                                       // Preset = Enable Clone mode
            *(uint32_t *)PIO_2_addr = cl_mode;                                    // Start conditions
            *(uint32_t *)PIO_1_addr = mode;                                       // ENABLE interface
            //
            if(DEBUG == TRUE) {
                printf("\n\r      Anzahl der Cylinder: %d ", MAXCYL );
            }
            //
            //---------------------------------------------------------------------+
            // First: find configured device number                                |
            //---------------------------------------------------------------------+
            FOUND = FALSE;
            if(FOUND == FALSE) {
                printf("\n\r      Drive_select #0 " );
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0010);   //#0
                usleep( 200*1000 );
                if (( *(uint32_t *)PIO_2_addr) & 0x1000) {
                    printf(" DRV_SLCTD = HIGH " );
                    FOUND=TRUE;
                }else{
                    printf(" DRV_SLCTD = LOW  " );
                    *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0010);
                }
            }           
            // ------------------------------------------------------------------
            if(FOUND == FALSE) {
                printf("\n\r      Drive_select #1 " );
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0020);   //#1
                usleep( 200*1000 );
                if (( *(uint32_t *)PIO_2_addr) & 0x1000) {
                    printf(" DRV_SLCTD = HIGH " );
                    FOUND=TRUE;
                }else{
                    printf(" DRV_SLCTD = LOW  " );
                    *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0020);
                
                }
            }               
            // ------------------------------------------------------------------
            if(FOUND == FALSE) {
                printf("\n\r      Drive_select #2 " );
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0040);   //#2
                usleep( 200*1000 );
                if (( *(uint32_t *)PIO_2_addr) & 0x1000) {
                    printf(" DRV_SLCTD = HIGH " );
                    FOUND=TRUE;
                }else{
                    printf(" DRV_SLCTD = LOW  " );
                    *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0040);
                }
            }           
            // ------------------------------------------------------------------
            if(FOUND == FALSE) {
                printf("\n\r      Drive_select #3 " );
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0080);   //#3
                usleep( 200*1000 );
                if (( *(uint32_t *)PIO_2_addr) & 0x1000) {
                    printf(" DRV_SLCTD = HIGH " );
                    FOUND=TRUE;
                }else{
                    printf(" DRV_SLCTD = LOW  " );
                    *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0080);
                }
            }           
            // 
            usleep( 200*1000 );
            //-------------------------------------------------------------------
            if (FOUND == FALSE ){
                printf("\n\r\n      !!! ERROR:  NO disk found  !!! \n\r" );
                fflush(stdout); 
                //while(1);
            }
            //-------------------------------------------------------------------
            if (( *(uint32_t *)PIO_2_addr) & 0x0100) {          
                printf("\n\r      READY =      HIGH " );
            }else{
                printf("\n\r      READY =      LOW  " );
            }
            //-------------------------------------------------------------------
            if (( *(uint32_t *)PIO_2_addr) & 0x0800) {
                printf("\n\r      SEEK_cmplt = HIGH " );
            }else{
                printf("\n\r      SEEK_cmplt = LOW  " );
            }
            //-------------------------------------------------------------------
            if (( *(uint32_t *)PIO_2_addr) & 0x0400) {
              printf("\n\r      TRACK_0 =    HIGH " );
            }else{
              printf("\n\r      TRACK_0 =    LOW  " );
            }
            //-------------------------------------------------------------------
            if (( *(uint32_t *)PIO_2_addr) & 0x1000) {
              printf("\n\r      DRV_SLCTD =  HIGH " );
            }else{
              printf("\n\r      DRV_SLCTD =  LOW  " );
            }
            //
            //------------------------------------------------------------------+
            // Check for Drive READY @ CL_I[8] = 0x0100                         |         
            //------------------------------------------------------------------+
            if (( *(uint32_t *)PIO_2_addr) & 0x0100) { 
                printf("\n\r      Drive = ready" );
            }else{
                printf("\n\r Drive is NOT ready, wait ...." );
                while (!(*(uint32_t *)PIO_2_addr & 0x0400)) { 
                    usleep( 500*1000 );
                    printf(".");
                    fflush(stdout);
                }
                printf("\n\r      Drive = ready, continue" );
            }
            //
            //------------------------------------------------------------------+
            // Check & if necessary, adjust to home position @ CL_I[10]=0x0400  |
            //------------------------------------------------------------------+
            if (( *(uint32_t *)PIO_2_addr) & 0x0400) {
                printf("\n\r      Drive is @ home" );
                fflush(stdout);
            }else{
                printf("\n\r      Drive is NOT @ home" );
                fflush(stdout);
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0100);             // HIGH: Step backward = to Home
                //*(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0100);          // LOW:  Step forward  = to Spindl
                //while ((*(uint32_t *)PIO_2_addr & 0x0400)) {                  // Step back, until
                while (!(*(uint32_t *)PIO_2_addr & 0x0400)) {                   // Step back, until
                    stepping();                                                 // track0 signal receiving
                }
                printf("\n\r    Drive positioned to home" );
                fflush(stdout);
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0100);            // LOW:  Step forward  = to Spindl
            }
            printf("\n\r\n" );
            //
            //------------------------------------------------------------------+
            // Start collecting data                                            |
            //------------------------------------------------------------------+
            for(steps=0; steps<MAXCYL; steps++) {
                printf("\r      Cloning cylinder %d  ", steps );
                fflush(stdout);
                *(uint32_t *)PIO_1_addr = (mode=mode|0x0008);                   // Disable  Clone_Enable
                //
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0001);             // Set head #1
                usleep( 2*1000 );                                               // Wait a little ....
                *(uint32_t *)PIO_1_addr = (mode=mode&~0x0008);                  // Enable  Clone_Enabel
                usleep( 100*1000 );                                             // Delay to get one Track into DPR
                *(uint32_t *)PIO_1_addr = (mode=mode|0x0008);                   // Disable  Clone_Enable                
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0001);            // Clear head #1
                usleep( 2*1000 );                                               // Wait a little ....
                //
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0002);             // Set head #2
                usleep( 2*1000 );                                               // Wait a little ....
                *(uint32_t *)PIO_1_addr = (mode=mode&~0x0008);                  // Enable  Clone_Enabel
                usleep( 100*1000 );                                             // Delay to get one Track into DPR
                *(uint32_t *)PIO_1_addr = (mode=mode|0x0008);                   // Disable  Clone_Enable
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0002);            // Clear head #2
                usleep( 2*1000 );                                               // Wait a little ....
                //              
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0004);             // Set head #3              
                usleep( 2*1000 );                                               // Wait a little ....
                *(uint32_t *)PIO_1_addr = (mode=mode&~0x0008);                  // Enable  Clone_Enabel
                usleep( 100*1000 );                                             // Delay to get one Track into DPR
                *(uint32_t *)PIO_1_addr = (mode=mode|0x0008);                   // Disable  Clone_Enable
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0004);            // Clear head #3
                usleep( 2*1000 );                                               // Wait a little ....
                //
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0008);             // Set head #4
                usleep( 2*1000 );                                               // Wait a little ....
                *(uint32_t *)PIO_1_addr = (mode=mode&~0x0008);                  // Enable  Clone_Enabel             
                usleep( 100*1000 );                                             // Delay to get one Track into DPR
                *(uint32_t *)PIO_1_addr = (mode=mode|0x0008);                   // Disable  Clone_Enable                
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0008);            // Clear head #4
                usleep( 2*1000 );                                               //wait
                //
                fflush(stdout);
                //
                //                                                              // ####################
                READ_drive_from_FPGA(SDRAM_adress);                             // ### FPGA-->Union ###
                //                                                              // ####################
                //
                stepping();                                                     // Seek forward, one cylinder
                //while (!(*(uint32_t *)PIO_2_addr & 0x0800));                  // Wait for "Seek complete"
                SDRAM_adress = SDRAM_adress + CYL_size;                         // Next Cylinder.   
            }           
            fflush(stdout);
            //
            //------------------------------------------------------------------+
            // Bring back in home-position                                      |
            //------------------------------------------------------------------+           
            printf("\n\r      back to home position" ); fflush(stdout);
            *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0100);                  // HIGH: Step backward = to Home
            while (!(*(uint32_t *)PIO_2_addr & 0x0400)) {
                stepping();
            }
            //
            //------------------------------------------------------------------+
            // Save data to Micro-SD-Card                                       |
            //------------------------------------------------------------------+                       
            printf ("\n\r      Save MFM - data to SD-Card into file:  %s  \n\r", myfile2);
            PRESET_one_SECTOR();
            WRITE_to_SD_Card();
			printf ("\n\r      Save IMG - data to SD-Card into file:  %s  \n\r", myfile3);
			WRITE_to_SD_Card3();
            //
            printf("\n\r   *********** Clone-Mode finished **********\n\r"); fflush(stdout);
            //while(1);
            //
            //
        }else{
            //
            printf("\n\r");
            printf("      ******************************************\n\r");
            printf("      ************** Emulator-Mode *************\n\r");
            printf("      ******************************************\n\r"); 
            //
            OFFLINE = 0;                                                   // ONLINE-Mode           
            cl_mode=0;
            *(uint32_t *)PIO_2_addr = cl_mode;                             // Disable Clone mode            
            //
            //
            //*************************************************************
            //   Check for SD card INIT Request ( SWITCH 00 @ I_ctrl[2])
            //*************************************************************
            if (( *(uint32_t *)PIO_1_addr) & 0x0004) {                              // (RE)Construct file on SD card ?
                printf("\n\r       Inizialize new disk file: %s ",myfile2);
                printf("\n\r       To continue, set SW-0,(=Nr.8) to OFF position.\n\r\n");
                fflush(stdout);
                while (( *(uint32_t *)PIO_1_addr) & 0x0004);
                make_myfile_on_SD_Card();
                printf ("\r\nConstruct ST506/ST412/ST225 disk-format in RAM ...");
                make_full_ST();
                printf(" done!");
                printf ("\r\n Dump RAM to SD-Card into file:");
                printf(" %s\n\n\r", myfile2 );
                PRESET_one_SECTOR();
                WRITE_to_SD_Card();         
            }else {                                                                   // Start normal
            //*******************************************************************
            //  Check for connected MFM controller , Power OK Signal @ I_ctrl[0]
            //*******************************************************************
                if(~( *(uint32_t *)PIO_1_addr) & 0x01) {
                    *(uint32_t *)PIO_1_addr = 0x0000;
                    printf("\n\r\x07\x1B[2J");                                             // VT100 EScape Sequenze : Clear_screen
                    printf("\n\r               System start not possible !      ");
                    printf("\n\r               No connection to controller    ");
                    printf("\n\r               Restart system and try again     ");
                    fflush(stdout);
                    while(1);
                } else {
                    if(~( *(uint32_t *)PIO_1_addr) & 0x20){
                        printf ("            Read SD-Card, file:  ");printf(" %s\n\r", myfile2 );
                        READ_from_SD_Card();
                        if(SECTOR.st_l[101] != 0x31504450 ) {
                            printf("\n\n\rSD-Card with illegal format detected !");
                            printf("\n\r               Restart system and try again     ");
                            fflush(stdout);
                            while(1);
                        }
                    }
                }
            }       
            //      
            //                              
            mode = 0x4001;                                                 // = start conditions set up
            *(uint32_t *)PIO_1_addr = mode;                                // Start, Step #1 of 2 = ENABLE interface
            //
            //
            //                                                             ####################
            WRITE_drive_to_FPGA(SDRAM_adress);//                           ### Union-->FPGA ###
            //                                                             ####################
            //
            //==========================================================================================
            printf("\r\n ********** S T A R T ST-506/412/225 Emulator *********** \n\r");
            //==========================================================================================
            //
            *(uint32_t *)PIO_1_addr = (mode=mode|0x00A0);                 // Output Enable + Drive Ready
            if(DEBUG == TRUE) {
                printf(" Started with operating mode:            ");
                print_binary_16bit_LSB(mode);printf("    \r\n\n\n");
            }           
            //
            //                                   §§§§§§§§§§§§§§§§§§§§§§§§§§
            //                                   §§§§§§§  MAIN LOOP §§§§§§§
            //                                   §§§§§§§§§§§§§§§§§§§§§§§§§§
            //
            //
            //signal(SIGINT, sigintHandler);             // Prevent abort by ctrl-C
            while(secwhile == 0) {                       // Secondary while
                //
                //------------------------------------------------------------------+
                // check for drive command @ I_ctrl[1]                              |
                //------------------------------------------------------------------+
                //        
                // First, copy/save data from DP-RAM to SDRAM
                if((OFFLINE == FALSE) | (OFFMODE == TRUE)) {                   // ####################
                    READ_drive_from_FPGA(SDRAM_adress);                        // ### FPGA-->Union ###
                }                                                              // ####################
                //
                if (( *(uint32_t *)PIO_1_addr) & 0x0002) {                           // test @ I_ctrl[1]            
                    if(DEBUG == TRUE){ 
                        printf("\n\r Step request received: ");
                    }
                    // wait for Step-Cycle complete signal coming from sequencer @ I_ctrl[4] DPR_size
                    while (!(*(uint32_t *)PIO_2_addr & 0x0010 ));
                    cylinder = *(uint32_t *)PIO_0_addr;                          // receive new cylinder #
                    SDRAM_adress = cylinder * DPR_size;                          // Calculate new SD-RAM address
                    if(DEBUG == TRUE) {
                        printf("\n\r  New cylinder address:         %d ", cylinder);
                        printf("\n\r  Point to #cylinder @ SD-RAM:  %d ", SDRAM_adress );
                    }
                    // restart cycle......
                    if((OFFLINE == FALSE) | (OFFMODE == TRUE)) {              // ####################
                        WRITE_drive_to_FPGA(SDRAM_adress);                    // ### Union-->FPGA ###
                    }                                                         // ####################
                    acknowledge();
                }                                                              // all done                  
                //
                //------------------------------------------------------------------+
                // check for power fail or reset                                    |
                //------------------------------------------------------------------+                                                           
                if (( ~ *(uint32_t *)PIO_1_addr & 0x8000 ) | ( ~ *(uint32_t *)PIO_1_addr & 0x0001 )) {
                    if( OFFLINE == FALSE ) {   
                        printf("    Key[1] / Power-fail   \n\r");
                        usleep( 500*1000 );
                        printf("\x1B[2J\n\r\x07        ......... Shutting down system .........\n\r");
                        //READ_drive_from_FPGA(Old_RAM_Address);
                        //Old_Cyl_nr = 0;
                        //....save
                        //WRITE_to_SD_Card();                    
                        *(uint32_t *)PIO_0_addr = 0x0000;                        // Clear PIO-0
                        *(uint32_t *)PIO_1_addr = 0x000C;                        // Clear PIO-1
                    } else {
                        *(uint32_t *)PIO_0_addr = 0x0000;                        // Clear PIO-0
                        *(uint32_t *)PIO_1_addr = 0x000C;                        // Clear PIO-1
                        printf("\x07\n\n\r        *** System switched down *** \n\r"); 
                    }
                    secwhile = 1;               
                }                       
            } // Secondary while
        }
        while ( ~ *(uint32_t *)PIO_1_addr & 0x8000 );   // Reset/Exit,       = Button 1 released
        usleep( 500*1000 );
        while ( ~ *(uint32_t *)PIO_1_addr & 0x4000 );   // Reconfig/Restart, = Button 2 released
        usleep( 500*1000 );
        printf("\x07\n\n\r  Press RESET/Button-1 for exit, Reconfig/Button-2 for restart  \n\r");
        priwhile = 2;
        while(priwhile == 2) {
            if ( ~ *(uint32_t *)PIO_1_addr & 0x4000 ) {  // Reconfig/Restart
                usleep( 500*1000 );
                secwhile = 0;
                priwhile = 0;
            }
            if ( ~ *(uint32_t *)PIO_1_addr & 0x8000 ) {  // Reset/EXit
                printf("\x07\n\n\r    Servus & Bye\n\r\n");
                fflush(stdout);
                usleep( 500*1000 );
                secwhile = 1;
                priwhile = 1;
            }
        }
    } // Primary while
    return 0; 
}