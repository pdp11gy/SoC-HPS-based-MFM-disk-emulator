#!/bin/sh
PATH=/cygdrive/C/altera_lite/16.1/quartus/sopc_builder/bin:$PATH
sopc-create-header-files \
"$PWD/MFM_system.sopcinfo" \
--single hps_0.h \
--module hps_0
