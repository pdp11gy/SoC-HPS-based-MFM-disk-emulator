/*
              *****************************************************************************
              *  Copyright (C)  by Reinhard Heuberger   www.pdp11gy.com                   *
              *                                                                           *
              *  All rights reserved.                                                     *
              *                                                                           *
              *  Redistribution and use in source and binary forms, with or without       *
              *  modification, are permitted provided that the following conditions       *
              *  are met:                                                                 *
              *                                                                           *
              *  1. Redistributions of source code must retain the above copyright        *
              *     notice, this list of conditions and the following disclaimer.         *
              *  2. Redistributions in binary form must reproduce the above copyright     *
              *     notice, this list of conditions and the following disclaimer in the   *
              *     documentation and/or other materials provided with the distribution.  *
              *  3. Neither the name of the author nor the names of its contributors may  *
              *     be used to endorse or promote products derived from this software     *
              *     without specific prior written permission.                            *
              *                                                                           *
              *****************************************************************************

                           MFM-DISK read+clone/emulator ST506/412/225
                           Version V.1.0 for SoC HPS FPGA-environment
                         Beta Version V010  for SoC HPS FPGA-environment
                                    ( Quartus Version 16.1 )
                                    based on DE10-Nano Board
                           by: Reinhard Heuberger , www.PDP11GY.com
                   https://github.com/pdp11gy/SoC-HPS-based-MFM-disk-emulator

                              *********************************
                                 Data - Structure and Mapping
                              Reference: SEAGATE Service Manuel
                              *********************************

                         |<-32 MB  SD RAM ->|      |<- DP-RAM-->|

              / 5.898240 +------------------+
             /           |   Cylinder #306  |      +------------+ 20832
   +--------+   5.886720 +------------------+     /|  Track #3  |>15624-20831
   |        |            |                  |    / |- - - - - - | 15624
   |   SD   |            .                  .   /  |  Track #2  |>10416-15623
   |  CARD  |            .                  .  /   |- - - - - - | 10416
   |        |            |                  | /    |  Track #1  |>05208-10415
   +--------+     20832  +------------------+/     |- - - - - - | 05208
             \           |    Cylinder #0   |      |  Track #0  |>00000-05207
              \   00000  +------------------+ - - -+------------+ 00000

       The ST506/412/225 disk drive did have a capacity of 6.38/12.76/20.0MB
                        ST506 = 153 cylinder ,  612 tracks
                        ST412 = 306 cylinder , 1224 tracks
                        ST225 = 615 cylinder , 2460 tracks
                                 32 sectors / track

        Nominal Track Capacity:           =    10416 ( Byte )
        Setzt sich wie folgt zusammen:

        Total Data Bytes/Track = 256   x 32 =     8192
        SYNC = 13x00           =  13   x 32 =      416
        ID AM = 2 Byte         =   2   x 32 =       64
        CYL/HD/SEC = 3 Byte    =   3   x 32 =       96
        Header-CRC = 2 Byte    =   2   x 32 =       64
        Gap2 3 + 13 = 16Byte   =  16   x 32 =      512
        Data AM = 2 Byte       =   2   x 32 =       64
        Data-CRC = 2 Byte      =   2   x 32 =       64
        Gap3 1of2 = 3x00       =   3   x 32 =       96
        Gap3 2of2 = 15x4E      =  15   x 32 =      480
                               ------------------------+-----------------
                         SECTOR: 314      TRACK: 10048 |  CYLINDER: 40192
        Einmalig dazu:   Gap1  16x4E      =         16 |               64
                         Gap4 352x4E      =        352 |             1408
                                       ----------------+-----------------
                             ( Byte )            10416 |            41664
                              ( Bit )            83328 |           333312
                             ( Word )             5208 |            20832
                             ==========================+=================

****************************************************************************************
                          DE10-Nano based mapping and implementation
                          ******************************************

  
                                     Decoded data MAPPING mfm
                                     ************************

              / 3.290112 +------------------+      +------------------->256 byte impure area
             /           |   Cylinder #306  |      +------------+ 43008
   +--------+   3.279360 +------------------+     /|  Track #3  |>32256-43007
   |        |            |                  |    / |- - - - - - | 32256
   |   SD   |            .                  .   /  |  Track #2  |>21504-32255
   |  CARD  |            .                  .  /   |- - - - - - | 21504
   |        |            |                  | /    |  Track #1  |>10752-21503
   +--------+     10752  +------------------+/     |- - - - - - | 10752
             \           |    Cylinder #0   |      |  Track #0  |>00000-10751
              \   00000  +------------------+ - - -+------------+ 00000
              
              

                                     Decoded gap MAPPING gap 
                                     ***********************

              / 52.641.792 +------------------+      +------------------->256 byte impure area
             /             |   Cylinder #306  |      +------------+ 172032
   +--------+   52.469.760 +------------------+     /|  Track #3  |>129024-172031
   |        |              |                  |    / |- - - - - - | 129024
   |   SD   |              .                  .   /  |  Track #2  |>86016-129023 
   |  CARD  |              .                  .  /   |- - - - - - | 86016
   |        |              |                  | /    |  Track #1  |>43008-86015
   +--------+       172032 +------------------+/     |- - - - - - | 43008
             \             |    Cylinder #0   |      |  Track #0  |>00000-43007
              \     000000 +------------------+ - - -+------------+ 00000

******************************************************************************************                        
                                    

*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include "hwlib.h"
#include "socal/socal.h"
#include "socal/hps.h"
#include "socal/alt_gpio.h"
#include "hps_0.h"
#include <signal.h>
//
//
void init_HW(void);
void init_DPRs(void);
void startup_leds(void);
void print_binary_16bit_LSB( unsigned short ibit16);
void PRESET_one_SECTOR(void);
//void make_header_CRC(void);
//void make_data_CRC(void);
//void make_full_ST(void);
//void make_bootsector(void);
void WRITE_drive_to_FPGA(int point_to_cylinder);
void READ_drive_from_FPGA(int point_to_cylinder);
void acknowledge(void);
void stepping(void);
void make_myfile_on_SD_Card(void);
void WRITE_to_SD_Card3(void);
void WRITE_to_SD_Card4(void);
void WRITE_to_SD_Card5(void);
void save_diskspeed_data(void);
void get_diskspeed_data(void);
void READ_from_SD_Card4(void);
void READ_from_SD_Card5(void);
void read_diskinfo(void);
void read_default_track(void);
//
//
typedef unsigned char byte;
//
#define HW_REGS_BASE ( ALT_STM_OFST )             // axi_lw
#define HW_REGS_SPAN ( 0x04000000 )               // Bridge span
#define HW_REGS_MASK ( HW_REGS_SPAN - 1 )
#define ALT_AXI_FPGASLVS_OFST (0xC0000000)        // axi_master
#define HW_FPGA_AXI_SPAN (0x40000000)             // Bridge span
#define HW_FPGA_AXI_MASK ( HW_FPGA_AXI_SPAN - 1 )
//
#define CYL_size   43008         // One cylinder size, byte
#define DPR_size   43008         // mfm data: Dual-Portet-RAM size
#define ST506_size 153           // ST506 = 153 cylinder (  5.40 MB )
#define ST412_size 306           // ST412 = 306 cylinder ( 10.16 MB )
#define ST225_size 615           // ST225 = 615 Cylinder ( 20.42 MB )
#define nrofgaps   172032        // number of MFM-gaps per cylinder
#define XDPR_size  172032        // gap data: Dual ported RAM size 
#define TRUE  1
#define FALSE 0
//
unsigned short int header_index =   7;                             // Header index = 7 (word) (15=byte)
unsigned short int data_start =    19;                             // + 12
unsigned short int data_CRC =     147;                             //    + 128
unsigned short int ST_unit  =       0;                             // current selected ST unit-number
unsigned short int ST_type  =       0;                             // Drive-Type
unsigned short int CYL_P = 15, HD_P = 17, SEC_P = 16;              // point to cylinder,head, sector
unsigned short int sec_track =      0;                             // Number of sectors in one Track
unsigned short int DataAM = 0xA5F8;                                // !!! Indicator Pattern before Data Field !!!
unsigned char DataAM_lsb, DataAM_msb;                              //  split in 2 bytes
//
short int mode=0;                                                  // System operating mode >general
short int cl_mode=0;                                               // System operating mode >clone-mode
unsigned char FOUND=0;                                             // drive found , clone mode
unsigned char DEBUG=0;                                             // DEBUG PURPOSE
unsigned char OFFLINE=0;                                           // online/offline mode
unsigned char OFFMODE=0;                                           // full/simple offline mode
unsigned char diskinfofile=0;                                      // disk info file found ?
unsigned char used_encoder = 0;                                    // O_ctrl[4] 
//
/*        *********************** Global Definitions **********************        */
//
//++++++++++++++++++++++++++++++++++ UNION's +++++++++++++++++++++++++++++++++++++++++++++++++++++++++
union std {                                  // ****** ST-506/412 sector ************
       unsigned char  st_c[512];             // Access to one sector via 314 bytes or
       unsigned short st_i[256];             // 157 16Bit words  , alligned to 512/256
       unsigned int   st_l[128];
};
//union  std SECTOR;                                               // define a union of type SECTOR
union  std SECTOR __attribute__ ((aligned(4)));                    // define a union of type SECTOR
union  std *u_stptr;                                               // pointer to union.
//
//                 ****** ST-412/506 u. ST225 @ SD-RAM/=union ********
//                     Virtual access to 306 cylinders(head 0 to 3)
//                     4heads: = 1 Cylinder =    42240 byte 
//                     ST506 , 153 Cylinder =  6462720 byte
//                     ST412 , 306 Cylinder = 12925440 byte
//                     ST225 , 615 Cylinder = 25977600 byte
union mfm {
       unsigned char  st_drive_c[25977600];    // current maximal memory usage 
       unsigned short st_drive_i[12988800];
       unsigned int   st_drive_l[6494400]; 
};
union  mfm MFMDISK __attribute__ ((aligned(4)));                   // define a union of type MFMDISK
union  mfm *u_st_drive_ptr;                                        // pointer to union
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//+++++++++++++++++++++++++++++++ gap data = byte arry +++++++++++++++++++++++++++++++++++++++++++++++++
//
unsigned char gaps[615][nrofgaps]; 
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//
int SDRAM                   = 26449920;                            // maximum used bytes SD-RAM
int SECsize                 = 512;                                 // Sector size , Byte
unsigned short MAXCYL       = 615;                                 // cylinder, ST412/ST506
int DPR_Byte                = DPR_size*2;                          // Dual_Ported_RAM ( MFM-data )
int mfmf=0, mfmw=0;                                                // index frequency and puls-width
//
//  
char myfile1[80];                                                  // Info file
char myfile2[80];                                                  // disk info file: diskinfo_n.inf
char myfile3[80];                                                  // image file with .dsk extension
char myfile4[80];                                                  // MFM decoded file with .mfm extension
char myfile5[80];                                                  // gap's collected file with .gap extension
char myfile6[80];                                                  // disk speed/index frequency data
char info[10];
//
//------------------------------------------------------------------------------------------------------
int fd;                                           // Hold FPGA address
void *virtual_base;                               // Virtual axi-lw addr that maps to physical
void *axi_virtual_base;                           // Virtual axi-master addr that maps to physical
void *PIO_0_addr;                                 // PIO-0 address
void *PIO_1_addr;                                 // PIO-1 address
void *PIO_2_addr;                                 // PIO-2 address
void *PIO_3_addr;                                 // PIO-3 address
void *PIO_4_addr;                                 // PIO-4 address
void *DPR;                                        // #1, Dual Ported Ram address
void *DPR_addr;                                   // #1, Dual Ported Ram address with AXI-Master
void *XDPR;                                       // #2, Dual Ported Ram address
void *XDPR_addr;                                  // #2, Dual Ported Ram address with AXI-Master
//void *UART0;                                    // UART_0 address
//------------------------------------------------------------------------------------------------------
//
unsigned char priwhile = 0;
unsigned char secwhile = 0;
//
//
//
void init_HW(void)
{
  //---------------------------------------------------------------------------------------------------
  // === get FPGA addresses ===
  // Open /dev/mem
  if( ( fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
        printf( "ERROR: could not open \"/dev/mem\"...\n" );
  return; }
  //---------------------------------------------------------------------------------------------------
  // Get virtual addr that maps to physical
  virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );
  if( virtual_base == MAP_FAILED ) {
        printf( "ERROR: mmap() failed...\n" );
        close( fd );
  return; }
  axi_virtual_base = mmap( NULL, HW_FPGA_AXI_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, ALT_AXI_FPGASLVS_OFST );
  //----------------------------------------------------------------------------------------------------
  //
  // Get the addresses that maps to the FPGA control
  PIO_0_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + PIO_0_BASE )
                                & ( unsigned long)( HW_REGS_MASK ) );
  PIO_1_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + PIO_1_BASE )
                                & ( unsigned long)( HW_REGS_MASK ) );
  PIO_2_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + PIO_2_BASE )
                                & ( unsigned long)( HW_REGS_MASK ) );
  PIO_3_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + PIO_3_BASE )
                                & ( unsigned long)( HW_REGS_MASK ) );
  PIO_4_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + PIO_4_BASE )
                                & ( unsigned long)( HW_REGS_MASK ) );
  //
  DPR =  virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + DPR_BASE )
                      & ( unsigned long)( HW_REGS_MASK ) );
  DPR_addr =   axi_virtual_base + ( ( unsigned long  )( DPR_BASE ));  // This works with DPR !!!
  //
  XDPR =  virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + XDPR_BASE )
                      & ( unsigned long)( HW_REGS_MASK ) );
  XDPR_addr =   axi_virtual_base + ( ( unsigned long  )( XDPR_BASE ));  // This works with DPR !!!
  //
  //  
  //UART0 = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + UART_0_BASE )
  //                    & ( unsigned long)( HW_REGS_MASK ) );
  if( virtual_base == MAP_FAILED ) {
        printf( "ERROR: mmap() failed...\n" );
        close( fd );
        return;
  }
  //
  //-----------------------------------------------------------------------------------------------------
  // 
}
//
void init_DPRs(void) {
    //
    int imfm, igap; 
    int mfm, gap;
    //------------------------------------------------ Preset start
    mfm = CYL_size/4;
    gap = nrofgaps/4;
    strcat( info, " track_1 " );
    for (imfm = 0; imfm < DPR_size; imfm++ ){
        MFMDISK.st_drive_c[imfm] = 'U';               // = 'U'; = 0x55;     
    }   
    for (igap = 0; igap < nrofgaps; igap++ ){
        gaps[0][igap] = 0xFF;                         // = 0xFF;
    }   
    memcpy(MFMDISK.st_drive_c + mfm-9, info, sizeof(info));
    memcpy((void*)&gaps[0][gap-9], info, sizeof(info));    
    // 
    mfm = mfm + CYL_size/4;
    gap = gap + nrofgaps/4;
    info[7] = '2';
    memcpy(MFMDISK.st_drive_c + mfm-9, info, sizeof(info));
    memcpy((void*)&gaps[0][gap-9], info, sizeof(info)); 
    //
    mfm = mfm + CYL_size/4;
    gap = gap + nrofgaps/4;
    info[7] = '3';
    memcpy(MFMDISK.st_drive_c + mfm-9, info, sizeof(info));
    memcpy((void*)&gaps[0][gap-9], info, sizeof(info)); 
    //
    mfm = mfm + CYL_size/4;
    gap = gap + nrofgaps/4;
    info[7] = '4';
    memcpy(MFMDISK.st_drive_c + mfm-9, info, sizeof(info));
    memcpy((void*)&gaps[0][gap-9], info, sizeof(info)); 
    //
    mode = 0x4001;  
    *(uint32_t *)PIO_1_addr = mode; //  = ENABLE interface
    //memcpy((void *)(XDPR_addr), &gaps[0][0], nrofgaps);
    memcpy((void *)(XDPR_addr), (void*)&gaps[0][0], nrofgaps);
    memcpy((void *)(DPR_addr),  &MFMDISK.st_drive_i[0], CYL_size);
    //
    //------------------------------------------------ Preset End
}
//
//
void startup_leds(void)
{
int loop_count;
int led_direction;
int led_mask;
loop_count = 0;
led_mask = 0x01;
led_direction = 0; // 0: left to right direction
    //
    while(loop_count < 3 )  {
      *(uint32_t *)PIO_0_addr = led_mask;
      usleep( 20*1000 );
      if (led_direction == 0){
            led_mask <<= 1;
            if (led_mask == (0x01 << (PIO_0_DATA_WIDTH-1)))
                 led_direction = 1;
        }else{
            led_mask >>= 1;
            if (led_mask == 0x01){ 
                led_direction = 0;
                loop_count++;
            }
        }        
    }
}
//
//
void print_binary_16bit_LSB( unsigned short ibit16)
// Representation: LSB on right site ( PDP-11 like)
{
 int i;
  for (i = 0; i < 16; i++ ){
       if(0x8000 & ibit16 ) {               // Test Bit 15
          printf("1");
          }
           else {
              printf("0");
           }
   ibit16 = ibit16 << 1;
  }
}
//
//
//
//- calcCRC16r ------------------------------------------------------
unsigned short int calcCRC16r(unsigned short int crc, unsigned short int c, unsigned short int mask)
//
// Note: This smart C-Code was not written by myself.
// Reference: http://www.mikrocontroller.net/topic/12177#2274632
{
  unsigned char i;
  for(i=0;i<8;i++)
  {
    if((crc ^ c) & 1) { crc=(crc>>1)^mask; }
    //if((crc = crc  ^ c) & 1) { crc=(crc>>1)^mask; }
    else crc>>=1;
    c>>=1;
  }
  return (crc);
}
//
//
void PRESET_one_SECTOR(void) {
  // +
  // initialize data for one sector used for test and reference purpose.
  // Without Gap1 & Gap4 = 314 Byte , 0 - 313
  // -
  int i;
  header_index = 7;                                                  //   7  **** Set ****
  data_start = header_index + 12;                                    //  19  **** Set ****
  data_CRC = data_start + 128;                                       // 147  **** Set ****
  CYL_P = 15; HD_P = 16; SEC_P = 17;
  //
  unsigned short mysector[]=
  { 0x0000, 0x0000, 0x0000, 0x0000,                                  //  SYNC 0-3(0-7)
    0x0000, 0x0000,                                                  //  SYNC 4-5(8-11)
    0xA100,                                                          //  6= ( SYNC(12), IDAM,1of2(13) )
    //
    0x00FE,                                                          //  7= ( IDAM,2of2(14), CYL(15)<-)
    0x0000,                                                          //  8= ( HD(16), SEC(17) )
    0x0000,                                                          //  9= Header-CRC(18-19)
    //
    0x0000, 0x0000, 0x0000, 0x0000,                                  //  Gap 2 10-13(20-27)
    0x0000, 0x0000, 0x0000, 0x0000,                                  //  Gap 2 14-17(28-35)
    0xF8A1,                                                          //  18= AM(36-37)
    //                                  DATA 19-147(38-293)
    0x0000, 0x0000,                                                   //  Data 00-01
    0xFF00, 0xFF00, 0xFF00, 0xFF00, 0xFF00, 0x0000, 0x0000, 0x0000,   //  Data 02-09
    0x3333, 0x3333, 0x3333, 0x3333, 0x3333, 0x0000, 0x0000, 0x5500,   //  Data 10-17
    0x5555, 0x5555, 0x5555, 0x5555, 0x0055, 0x0000, 0x0000, 0x9249,   //  Data 18-25
    0x4924, 0x2492, 0x9249, 0x0024, 0x0000, 0x0000, 0x9123, 0x23DC,   //  Data 26-33
    0xDC91, 0x9123, 0x00DC, 0x0000, 0x0000, 0x8080, 0x8080, 0x8080,   //  Data 34-41
    0x8080, 0x8080, 0x0000, 0x0000, 0xE700, 0xF39C, 0x9CE7, 0xE7F3,   //  Data 42-49
    0xF39C, 0x0000, 0x0000, 0x6300, 0xF18C, 0x8C63, 0x63F1, 0xF18C,   //  Data 50-57
    0x0000, 0x0000, 0x7F00, 0x7F7F, 0x7F7F, 0x7F7F, 0x7F7F, 0x007F,   //  Data 58-65
    0x0000, 0x0000, 0x0D0A, 0x464D, 0x2D4D, 0x5320, 0x4D49, 0x4C55,   //  Data 66-73
    0x5441, 0x524F, 0x5620, 0x4E4F, 0x5220, 0x4945, 0x484E, 0x5241,   //  Data 74-81
    0x2044, 0x4548, 0x4255, 0x5245, 0x4547, 0x0A52, 0x4D0D, 0x4D46,   //  Data 82-89
    0x202D, 0x4953, 0x554D, 0x414C, 0x4F54, 0x2052, 0x4F56, 0x204E,   //  Data 90-97
    0x4552, 0x4E49, 0x4148, 0x4452, 0x4820, 0x5545, 0x4542, 0x4752,   //  Data 98-105
    0x5245, 0x0D0A, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF,   //  Data 106-113
    0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF,   //  Data 114-121
    0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x0000,                   //  Data 122-127
    0x3A33,                                                           //  147= Data 128 = CRC
    //
    0x0000, 0x4E00, 0x4E4E, 0x4E4E,                                   //  148-151 = Gap 3
    0x4E4E, 0x4E4E, 0x4E4E, 0x4E4E, 0x4E4E,                           //  152-156 = Gap 3
    0x0000, 0x0000, 0x0000, 0x0000 };                                 //  157-160 = ** Dummy,END of Data **
    //
    //
    for (i = 0; i < 256; i++ ){ SECTOR.st_i[i] = 0x0000; }           // clear buffer
    for (i = 0; i < 160; i++ ){ SECTOR.st_i[i] = mysector[i]; }      // Load buffer
    //make_data_CRC();
    //printf("\n\r Data-CRC 0X3A33 calculated : %#X \n",SECTOR.st_i[data_CRC]);
    //print_sector();
    SECTOR.st_l[100]=0x2E575757; // "WWW."
    SECTOR.st_l[101]=0x31504450; // "PDP1"
    SECTOR.st_l[102]=0x2E594731; // "1GY."
    SECTOR.st_l[103]=0x204D4F43; // "COM "
    SECTOR.st_l[127]=0x45444E45; // "ENDE" = Indicator
}
//
//
/*
void make_header_CRC(void){
  unsigned short int DEVICE_CRC16;
  //
  DEVICE_CRC16 = 0;                             // preset Data-CRC
  //DEVICE_CRC16 = 0xFFFF;                      // preset Data-CRC
  //
  // Header - Word 1 of 3  ( data )
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.st_c[header_index*2],0xA001);   //HSB
  //DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.st_c[header_index*2+1],0xA001); //LSB
  // Header - Word 2 of 3
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.st_c[header_index*2+2],0xA001); //HSB
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.st_c[header_index*2+3],0xA001); //LSB
  // Header - Word 3 of 3  -> Header-CRC
  SECTOR.st_i[header_index+2]=DEVICE_CRC16;  //Save CRC
  
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.st_c[CYL_P],0xA001);  //MSB
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.st_c[HD_P],0xA001);   //LSB
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.st_c[SEC_P],0xA001);  //MSB
  // Header - Word 3 of 3  -> Header-CRC
  SECTOR.st_i[header_index+2]=DEVICE_CRC16;  //Save CRC
}
//
//
void make_data_CRC(void){
  unsigned short int i, MSB, LSB;
  unsigned short int DEVICE_CRC16;
  //
  DEVICE_CRC16 = 0;                                    // preset Data-CRC
  //DEVICE_CRC16 = 0xFFFF;                             // preset Data-CRC
  //
  for (i = (data_start); i < (data_CRC); i++ ){
    MSB = i<<1;
    LSB = MSB + 1;
    DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.st_c[MSB],0xA001);
    DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.st_c[LSB],0xA001);
  }
  SECTOR.st_i[data_CRC] = DEVICE_CRC16;       // SET DATA-CRC
}

                         HEADER representation (LSB first)
          15                          8 7                          0
           +---------------------------+---------------------------+
   word#7  |     (15)CYLINDER          |  (14)IDAM(byte 2of2)=FE   |
           +---------------------------+---------------------------+
   word#8  |      (17)SECTOR           |7|6|5|    (16)HEAD         |
           +---------------------------+---------------------------+
   word#9  |                      HEADER  CRC                      |
           +-------------------------------------------------------+
   Note:
   Bit 5 of Head Byte reserved for numbering cylinder greater than 256
   Bit 6 of Head Byte reserved for numbering cylinder greater than 512
   Bit 7 of Head Byte ID Field equals 1 in a defective sector ( not used,=0 )


void make_full_ST(void) {
    // +
    // construct full ST-disk image in Memory ( union = SD RAM ). The idea behind this
    // routine is to dump the memory contents in pieces of 512 byte to the SD-Card after
    // constructing the ST-disk image in Memory.
    // -
    unsigned short int ST_cylinder, ST_track, ST_sector;
    int SDRAM=0, i, j;
    unsigned char head = 0, cyl = 0;
    //
    unsigned char interleave[]=
        { 0,8,16,24,1,9,17,25,2,10.18,26,3,11,19,27,
          4,12,20.28,5,13,21,29,6,14,22,30,7,15,23,31};
    //
    //
    for (ST_cylinder = 0; ST_cylinder < MAXCYL; ST_cylinder++ ) {                // ** 153(ST506)/306(ST412) Cylinder
        //
        head = 1;
        for (ST_track = 0; ST_track < 4; ST_track++ ) {                            // ** 4 Tracks(heads) +
            //
            for ( i = SDRAM; i < SDRAM+16 ; i++) {
                MFMDISK.st_drive_c[i] = 0x4E; 
            }                                                                     // A) Make Gap 1
            SDRAM = SDRAM + 16;
            //
            for (ST_sector = 0; ST_sector < 32; ST_sector++ ) {                                // ** 32 Sectors +
                SECTOR.st_c[HD_P]    = head;                                                   // SET Head
                SECTOR.st_c[SEC_P]   = interleave[ST_sector];                                  // SET Sector
                SECTOR.st_c[CYL_P]   = (ST_cylinder & 0xff);                                   // set cylinder bit 0-7
                SECTOR.st_c[HD_P] = SECTOR.st_c[HD_P] | (((ST_cylinder & 0x0300)>>3) & 0xff);  // bit 8+9
                make_header_CRC();
                //
                j=0;
                for(i = SDRAM; i< SDRAM+314; i++) {
                    MFMDISK.st_drive_c[i] = SECTOR.st_c[j];                      // Copy sector into RAM
                    j++;
                }
            SDRAM = SDRAM + 314;
            }                                                                    // ** 32 Sectors -
            for ( i = SDRAM; i < SDRAM+352 ; i++) {                              // B) Make Gap 4
                MFMDISK.st_drive_c[i] = 0x4E; 
            }
            SDRAM = SDRAM + 352;
            head = head <<1;                                                     // next head
        }                                                                        // ** 4 Tracks(heads) -
        //
        cyl++;
        //printf("\n\r  Cylinder: %d    SDRAM: %d", cyl, SDRAM );
    }                                                                            // ** 306 Cylinder -
    make_bootsector();
}
//
//
void make_bootsector(void) {
    //+
    //Only useful in a DEC environment
    //-
    short int i, data_begin;
    unsigned short bootsector[]=
    { 0x00A0, 0x0005, 0x0104, 0x0000, 0x0000, 0x4310, 0x9C10, 0x0100,        // * ..........C....*
      0x0837, 0x0024, 0x000D, 0x0000, 0x0A00, 0x423F, 0x4F4F, 0x2D54,        // *7.$.......?BOOT-*
      0x2D55, 0x6F4E, 0x6220, 0x6F6F, 0x2074, 0x6E6F, 0x7620, 0x6C6F,        // *U-No boot on vol*
      0x6D75, 0x0D65, 0x0A0A, 0x0080, 0x8BDF, 0xFF74, 0x80FD, 0x941F,        // *ume....._.t.}...*
      0xFF76, 0x80FA, 0x01FF, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000 };      // *v.z.............*
    //
    data_begin = data_start/2;                                               // byte to 16bit word
    for (i = data_begin; i < data_begin+128; i++ )
        { SECTOR.st_i[i] = 0x0000; }                                         // clear data area
    for (i = 0; i < 40; i++){
        SECTOR.st_i[i+data_begin] = bootsector[i];                           // init Sector
    }
    make_data_CRC();                                                         // -->CRC
    for (i = data_begin; i < data_begin+128; i++ ){                          // Copy sector into RAM
        MFMDISK.st_drive_i[i+8] = SECTOR.st_i[i];                            // Gap1 End = @16, = 8words
    }
    //printf ("\n\r   Boot sector done \n\r ");
}


*/
//
//
//
//
void WRITE_drive_to_FPGA(int point_to_cylinder){
    //
    // This routine writes one cylinder from union MFMDISK.st_drive_i to FPGA/DP-RAM
    //                               ####################
    //                               ### Union-->FPGA ###
    //                               ####################
    //
    memcpy((void *)(DPR_addr), &MFMDISK.st_drive_i[point_to_cylinder], CYL_size);
    //
}
//
void READ_drive_from_FPGA(int point_to_cylinder){
    //
    // This routine reads one cylinder from FPGA/DP-RAM into union MFMDISK.st_drive_i
    //                               ####################
    //                               ### FPGA-->Union ###
    //                               ####################
    //
    //
    memcpy(&MFMDISK.st_drive_i[point_to_cylinder], (void *)(DPR_addr), CYL_size);
    //
}
//
//
void acknowledge(void){
  // Terminate Seek-cycle,  sending a acknowledge pulse  @ O_ctrl[2]
  *(uint32_t *)PIO_1_addr = (mode=mode|0x0004);                     // Set Acknowledge
  usleep( 1000 );
  *(uint32_t *)PIO_1_addr = (mode=mode&~0x0004);                    // Clear Acknowledge
}
//
//
void stepping(void){
    //
    // Generate 1 Step puls. Note:
    //IOWR_ALTERA_AVALON_PIO_DATA(PIO_2_BASE, (cl_mode=cl_mode|0x0100));      // HIGH: Step backward = to Home
    //IOWR_ALTERA_AVALON_PIO_DATA(PIO_2_BASE, (cl_mode=cl_mode&~0x0100));     // LOW:  Step forward  = to Spindl
    //
    *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0200);
    usleep( 10*1000 ); // 
    *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0200);
    usleep( 10*1000 ); //
}
//
//
void make_myfile_on_SD_Card(void){
  FILE    *fptr;
  //
  fptr = fopen(myfile1, "w");
  if(fptr == NULL) {
    printf ("\n\r\x07 ERROR open/write file %s \n\r", myfile1);
    while(1); }
  fprintf(fptr,"      SOC/HPC based V 1.0 MFM disk reader/emulator    \r\n");
  fprintf(fptr,"          developed with Quartus Version 16.1         \r\n");
  fprintf(fptr,"         Copyright (C) by Reinhard Heuberger          \r\n");
  fprintf(fptr,"          www.pdp11gy.com  info@pdp11gy.com           \r\n");
  fclose(fptr);
  //
}
//
//
void WRITE_to_SD_Card4(void){                                   // .mfm file
    //
    // ST506: 5,62 MB ( 5.898.752 Bytes)
    // ST412: 12,1 MB (12.750.848 Bytes)
    //
    //int *my_BUFFER = (void*)&RLDRIVE.rl_drive_c[0];
    //printf(" size:  %d \n\r", (int)sizeof(RLDRIVE.rl_drive_c) );
    //
    FILE    *fptr;
    int loops=SDRAM/DPR_size, i=0, j=0;
    //
    fptr = fopen(myfile4, "wb");
    if(fptr == NULL) {
        printf ("\n\r\x07 ERROR open/write image file %s \n\r", myfile4);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    for(j=0; j<loops; j++) {
        fwrite((void*)&MFMDISK.st_drive_c[i], 1 , DPR_size, fptr );
        i=i+DPR_size;
    }
    fwrite((void*)&SECTOR.st_c[0], 1, 512, fptr );
    //
    fclose(fptr);   
}
//
void WRITE_to_SD_Card3(void){                                   // .dsk file
    //
    FILE    *fptr;
    int i=0;
    //
    //printf("\n\r   Trigger DataAM: lsb : 0x%02X  msb: 0x%2X  ",DataAM_msb,DataAM_lsb );
    fptr = fopen(myfile3, "wb");
    if(fptr == NULL) {
        printf ("\n\r\x07 ERROR open/write image file %s \n\r", myfile3);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    for ( i = 0; i < ((CYL_size*2) * MAXCYL); i++) {   
        if((MFMDISK.st_drive_c[i] == DataAM_msb) & (MFMDISK.st_drive_c[i+1] == DataAM_lsb) ) {
            fwrite((void*)&MFMDISK.st_drive_c[i+2], 1 , SECsize , fptr );
            i=i+SECsize+5;
        }   
    }   
    fclose(fptr);   
}
//
void WRITE_to_SD_Card5(void){                                   // .gap file
    //
    //
    int i;
    FILE    *fptr;
    //
    fptr = fopen(myfile5, "wb");
    if(fptr == NULL) {
        printf ("\n\r\x07 ERROR open/write image file %s \n\r", myfile5);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
//  for ( i = 0; i < 512 ; i++) {
//      printf("\n\r Wert von gaps[%d] = %01X ",i, gaps[0][i]);
//  }
    for ( i = 0; i < MAXCYL ; i++) {
    fwrite((void*)&gaps[i][0], 1 , nrofgaps, fptr );
    }
    fclose(fptr);
}
//
void save_diskspeed_data(void){
    FILE    *fptr;
    //
    fptr = fopen(myfile6, "wb");
    if(fptr == NULL) {
        printf ("\n\r\x07 ERROR open/write disk speed data file %s \n\r", myfile6);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    fprintf(fptr , "%d,%d\n", mfmf,mfmw);
    fclose(fptr);
    
}
//
void get_diskspeed_data(void){
    FILE    *fptr;
    int temp1, temp2;
    //
    if(diskinfofile == TRUE) {
        fptr = fopen(myfile6, "rb");
        if(fptr == NULL) {
            printf ("\n\r\x07 ERROR open/write disk speed data file %s \n\r", myfile6);
            *(uint32_t *)PIO_1_addr = 0x0000;
            while(1);
        }
        fscanf(fptr, "%d, %d",&temp1,&temp2);
        fclose(fptr);
        mfmf = temp1;
        mfmw = temp2;
    }
}
//
void READ_from_SD_Card4(void){                                              // .mfm file
    //
    // ST506: 5,62 MB ( 5.898.752 Bytes)
    // ST412: 12,1 MB (12.750.848 Bytes)
    //
    //int *my_BUFFER = (void*)&RLDRIVE.rl_drive_c[0];
    //printf(" size:  %d \n\r", (int)sizeof(RLDRIVE.rl_drive_c) )
    //
    FILE    *infile = 0;
    int loops=SDRAM/DPR_size, i=0, j=0;
    //
    infile = fopen(myfile4, "rb");
    if(infile == NULL) {
        printf ("\n\n\n\r\x07 ERROR open/read  .mfm file %s \n\r", myfile4);
        printf ("FIX THIS PROBLEM AND RESTART");
        fflush(stdout);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    for(j=0; j<loops; j++) {
        fread ((void*)&MFMDISK.st_drive_c[i], 1 , DPR_size, infile );
        i=i+DPR_size;
    }  
    fread((void*)&MFMDISK.st_drive_c[0], 1, 512, infile );
    fclose(infile);  
}
//
void READ_from_SD_Card5(void){                                             // .gap file
    FILE    *infile = 0;
    int i;
    //
    infile = fopen(myfile5, "rb");
    if(infile == NULL) {
        printf ("\n\n\n\r\x07 ERROR open/read  .gap file %s \n\r", myfile5);
        printf ("FIX THIS PROBLEM AND RESTART");
        fflush(stdout);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    for ( i = 0; i < MAXCYL ; i++) {
       fread((void*)&gaps[i][0], 1 , nrofgaps, infile );
    }  
    fclose(infile); 
}
//
void read_diskinfo(void) {
    FILE    *fptr;
    //int reserv1, reserv2;
    int j,temp1,temp2,temp3,temp4;
    char EineZeile[100];
    int string_over = 0;
    string_over = 0;
    fptr = fopen(myfile2, "r");
        if(fptr == NULL) {
            printf ("\n\n\r\x07 ERROR opening disk configuration file: %s \n\n\r", myfile2);
            diskinfofile = FALSE;
        } else {
            diskinfofile = TRUE;
            while( !feof( fptr )  ) {
                if( (string_over == 0) | (string_over == 2) ) {                 
                    fgets(EineZeile, sizeof(EineZeile), fptr);      // read EineZeile
                    if (EineZeile[0] =='#'){
                        printf ("%s", EineZeile);
                    } else {
                        if(string_over == 0) {
                            for(j=0; j<100; j++) {                 // Return + newline rausfiltern
                                if((EineZeile[j] == 0xD) |         // = 13. = return
                                   (EineZeile[j] == 0xA)) {        // = 10. = linefeed
                                    EineZeile[j] = 0;
                                }
                            }
                            strcpy(myfile3, EineZeile);
                            strcpy(myfile4, EineZeile);
                            strcpy(myfile5, EineZeile);
                            string_over = 1;
                        }
                    }
                } else {
                    fscanf(fptr, "%d, %d, %d, %X",&temp4,&temp1,&temp2,&temp3);
                    //XDPR_Byte   = reserv1;
                    //DPR_Byte    = reserv2;
                    sec_track   = temp4;
                    SECsize     = temp1;
                    MAXCYL      = temp2;
                    DataAM      = temp3;                    
                    string_over = 2;
                }
            }
            fclose(fptr);
        }
    fflush(stdout); 
}
//
//
void read_default_track(void){
    FILE    *infile = 0;
    int track_mfm =  DPR_size/4;
    int track_gap =  nrofgaps/4;
    int i=0;
    //
    // read 1 track from .mfm + .gap default file
    //
    infile = fopen(myfile4, "rb");                        // .mfm default
    if(infile == NULL) {
        printf ("\n\n\n\r\x07   ERROR open/read  .mfm file %s \n\r", myfile4);
        printf ("   FIX THIS PROBLEM AND RESTART");
        fflush(stdout);
        *(uint32_t *)PIO_1_addr = 0x0000;
        fflush(stdout);
        while(1);
    }
    fread ((void*)&MFMDISK.st_drive_c[0], 1 , track_mfm, infile );
    fclose(infile);
    memcpy(&MFMDISK.st_drive_c[track_mfm*1], &MFMDISK.st_drive_c[0], track_mfm);
    memcpy(&MFMDISK.st_drive_c[track_mfm*2], &MFMDISK.st_drive_c[0], track_mfm);
    memcpy(&MFMDISK.st_drive_c[track_mfm*3], &MFMDISK.st_drive_c[0], track_mfm);
    //
    infile = fopen(myfile5, "rb");                      // .gap default
    if(infile == NULL) {
        printf ("\n\n\n\r\x07   ERROR open/read  .gap file %s \n\r", myfile5);
        printf ("  FIX THIS PROBLEM AND RESTART");
        fflush(stdout);           
        *(uint32_t *)PIO_1_addr = 0x0000;
        fflush(stdout);
        while(1);
    }    
    fread((void*)&gaps[0][0], 1 , track_gap, infile );
    fclose(infile);
    memcpy((void*)&gaps[0][track_gap*1], (void*)&gaps[0][0], track_gap);
    memcpy((void*)&gaps[0][track_gap*2], (void*)&gaps[0][0], track_gap);
    memcpy((void*)&gaps[0][track_gap*3], (void*)&gaps[0][0], track_gap);
    //
    for(i=1; i<MAXCYL; i++) {
    memcpy(&MFMDISK.st_drive_c[i*DPR_size], &MFMDISK.st_drive_c[0], DPR_size);
    memcpy((void*)&gaps[i][0], (void*)&gaps[0][0], nrofgaps);   
    }
}
//
//
//
//
//                                            §§§§§§§§§§§§§§§§§§§§§§§§§§
//                                            §§§§§§§    MAIN    §§§§§§§
//                                            §§§§§§§§§§§§§§§§§§§§§§§§§§
//
int main()
{   
    int steps;
    int SDRAM_adress = 0;
    int Old_SDRAM_address = 0;
    unsigned short int cylinder=0;
    unsigned short int Old_cylinder=0;
    float speed, mfm_f, mfm_w;
    strcpy( myfile1, "PDP11GY.INF" );
    char buffer[10];
    char extension2[6] = ".inf";
    char extension3[6] = ".dsk";
    char extension4[6] = ".mfm";
    char extension5[6] = ".gap";
    //
    FOUND   = 0;
    cl_mode = 0;
    mode    = 0;
    init_HW();
    *(uint32_t *)PIO_0_addr = mode;                     // Clear PIO-0
    *(uint32_t *)PIO_1_addr = mode;                     // Clear PIO-1
    *(uint32_t *)PIO_2_addr = cl_mode;                  // Clear PIO-2
    init_DPRs();
    //
    while(priwhile == 0) {                              // Primary while
        //
        printf("\n\r\x1B[2J");
        printf("        ** MFM-DISK Reader/Cloner+EMULATOR @ Soc/ HPS **               \n\r");
        printf("        DE10-Nano  ST-506/412/225 emulator Version V.1.0               \n\r");
        printf("        ***********************|************************               \n\r");
        printf("                     (c) WWW.PDP11GY.COM                               \n\r");
        //
        startup_leds();
        PRESET_one_SECTOR();
        //
        // >>>>>>>>>>>>>>>>>> Check for debug mode <<<<<<<<<<<<
        if (( *(uint32_t *)PIO_2_addr) & 0x0040) {
           DEBUG = 1;
           printf ("\n\r              >>>>>> DEBUG-MODE = ON <<<<<<");
        } else {
           DEBUG = 0;
           printf ("\n\r              >>>>>> DEBUG-MODE = OFF <<<<<");
        }
        //
        //
        strcat( myfile2, "diskinfo_" );
        strcat( myfile6, "disk_speed_" );
        ST_type = ( *(uint32_t *)PIO_2_addr) &~0xFFF0;
        sprintf(buffer, "%d", ST_type);
        strcat(myfile2, buffer);
        strcat(myfile6, buffer);
        strcat(myfile2, extension2);
        strcat(myfile6, extension2);
        printf ("\n\r             Disk config file:  %s  \n\r", myfile2);
        // ----------------------------------------------------------------
        read_diskinfo();
        // ----------------------------------------------------------------
        if(diskinfofile == FALSE) {
            if (( *(uint32_t *)PIO_1_addr) & 0x0020) {  
                printf("             Fix this problem and restart \n\n\r");
                fflush(stdout);
                usleep( 5*10000 );
                return 0;
            } else {
                printf("           +---------------------------------+ \n");
                printf("           |  No config file, using default  | \n");
                printf("           +---------------------------------+ \n");
                strcpy(myfile3, "default");
                strcpy(myfile4, "default");
                strcpy(myfile5, "default");
                MAXCYL = 306;
                mfmf = 1344179;
                mfmw = 132790;
                fflush(stdout);
            }               
        }
        printf("\n\r disk-data: sector-size: %d  nr. of Cylinder: %d  DataAM: %X\n\r",
        SECsize,MAXCYL,DataAM );
        strcat(myfile3, extension3);
        strcat(myfile4, extension4);
        strcat(myfile5, extension5);
        printf("      myfile3 = %s \r\n", myfile3);
        printf("      myfile4 = %s \r\n", myfile4);
        printf("      myfile5 = %s \r\n", myfile5);       
        //
        fflush(stdout);
        DataAM_lsb = (unsigned)DataAM & 0xff;     // mask the lower 8 bits
        DataAM_msb = (unsigned)DataAM >> 8;       // shift the higher 8 bits
        *(uint32_t *)PIO_3_addr = DataAM ;        // Send DataAM to MFM decoder
        //
        //      
        //      
        if (( *(uint32_t *)PIO_1_addr) & 0x0020) {
            //
            printf("      ******************************************\n\r");
            printf("      **************** Clone-Mode **************\n\r");
            printf("      ******************************************\n\r");
            mode = 0x4001;                                                        // **********************
            *(uint32_t *)PIO_1_addr = mode;                                       // Disable Simulator mode
            //                                                                    // **********************
            //                                                                                                                                        
            // Set Start-condition: CL_TRI_control
            cl_mode=0x8000;                                                       // Preset = Enable Clone mode
            *(uint32_t *)PIO_2_addr = cl_mode;                                    // Start conditions
            *(uint32_t *)PIO_1_addr = mode;                                       // ENABLE interface
            //
            if(DEBUG == TRUE) {
                printf("\n\r      Anzahl der Cylinder: %d ", MAXCYL );
            }
            //
            //---------------------------------------------------------------------+
            // First: find configured device number                                |
            //---------------------------------------------------------------------+
            FOUND = FALSE;
            if(FOUND == FALSE) {
                printf("\n\r      Drive_select #0 " );
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0010);   //#0
                usleep( 200*1000 );
                if (( *(uint32_t *)PIO_2_addr) & 0x1000) {
                    printf(" DRV_SLCTD = HIGH " );
                    FOUND=TRUE;
                }else{
                    printf(" DRV_SLCTD = LOW  " );
                    *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0010);
                }
            }           
            // ------------------------------------------------------------------
            if(FOUND == FALSE) {
                //printf("      **************** +Test-Mode **************\n\r");
                printf("\n\r      Drive_select #1 " );
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0020);   //#1
                usleep( 200*1000 );
                if (( *(uint32_t *)PIO_2_addr) & 0x1000) {
                    printf(" DRV_SLCTD = HIGH " );
                    FOUND=TRUE;
                }else{
                    printf(" DRV_SLCTD = LOW  " );
                    *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0020);
                
                }
            }               
            // ------------------------------------------------------------------
            if(FOUND == FALSE) {
                printf("\n\r      Drive_select #2 " );
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0040);   //#2
                usleep( 200*1000 );
                if (( *(uint32_t *)PIO_2_addr) & 0x1000) {
                    printf(" DRV_SLCTD = HIGH " );
                    FOUND=TRUE;
                }else{
                    printf(" DRV_SLCTD = LOW  " );
                    *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0040);
                }
            }           
            // ------------------------------------------------------------------
            if(FOUND == FALSE) {
                printf("\n\r      Drive_select #3 " );
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0080);   //#3
                usleep( 200*1000 );
                if (( *(uint32_t *)PIO_2_addr) & 0x1000) {
                    printf(" DRV_SLCTD = HIGH " );
                    FOUND=TRUE;
                }else{
                    printf(" DRV_SLCTD = LOW  " );
                    *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0080);
                }
            }           
            // 
            usleep( 200*1000 );
            //-------------------------------------------------------------------
            if (FOUND == FALSE ){
                printf("\n\r\n      !!! ERROR:  NO disk found  !!! \n\r" );
                fflush(stdout); 
                //while(1);
            }
            //-------------------------------------------------------------------
            if (( *(uint32_t *)PIO_2_addr) & 0x0100) {          
                printf("\n\r      READY =      HIGH " );
            }else{
                printf("\n\r      READY =      LOW  " );
            }
            //-------------------------------------------------------------------
            if (( *(uint32_t *)PIO_2_addr) & 0x0800) {
                printf("\n\r      SEEK_cmplt = HIGH " );
            }else{
                printf("\n\r      SEEK_cmplt = LOW  " );
            }
            //-------------------------------------------------------------------
            if (( *(uint32_t *)PIO_2_addr) & 0x0400) {
              printf("\n\r      TRACK_0 =    HIGH " );
            }else{
              printf("\n\r      TRACK_0 =    LOW  " );
            }
            //-------------------------------------------------------------------
            if (( *(uint32_t *)PIO_2_addr) & 0x1000) {
              printf("\n\r      DRV_SLCTD =  HIGH " );
            }else{
              printf("\n\r      DRV_SLCTD =  LOW  " );
            }
            //
            //------------------------------------------------------------------+
            // Check for Drive READY @ CL_I[8] = 0x0100                         |         
            //------------------------------------------------------------------+
            if (( *(uint32_t *)PIO_2_addr) & 0x0100) { 
                printf("\n\r      Drive = ready" );
            }else{
                printf("\n\r Drive is NOT ready, wait ...." );
                while (!(*(uint32_t *)PIO_2_addr & 0x0400)) { 
                    usleep( 500*1000 );
                    printf(".");
                    fflush(stdout);
                }
                printf("\n\r      Drive = ready, continue" );
            }
            //
            //------------------------------------------------------------------+
            // Check & if necessary, adjust to home position @ CL_I[10]=0x0400  |
            //------------------------------------------------------------------+
            if (( *(uint32_t *)PIO_2_addr) & 0x0400) {
                printf("\n\r      Drive is @ home" );
                fflush(stdout);
            }else{
                printf("\n\r      Drive is NOT @ home" );
                fflush(stdout);
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0100);             // HIGH: Step backward = to Home
                //*(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0100);          // LOW:  Step forward  = to Spindl
                //while ((*(uint32_t *)PIO_2_addr & 0x0400)) {                  // Step back, until
                while (!(*(uint32_t *)PIO_2_addr & 0x0400)) {                   // Step back, until
                    stepping();                                                 // track0 signal receiving
                }
                printf("\n\r    Drive positioned to home" );
                fflush(stdout);
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0100);            // LOW:  Step forward  = to Spindl
            }
            //
            //------------------------------------------------------------------+
            //   get disk speed data                                            |
            //------------------------------------------------------------------+
            // ***************************************************************
            *(uint32_t *)PIO_1_addr = (mode=mode|0x0200);                   // set to index pulse-width measurement
            usleep( 500*1000 );
            mfmw = *(uint32_t *)PIO_4_addr;
            mfm_w = mfmw*0.0125;
            printf("\n\r\n     index puls-width :  %d  =  %.3f us  ", mfmw, mfm_w);
            fflush(stdout);
            *(uint32_t *)PIO_1_addr = (mode=mode&~0x0200);                  // set to index frequency measurement
            usleep( 500*1000 );
            mfmf = *(uint32_t *)PIO_4_addr;
            mfm_f = mfmf*0.0125;
            printf("\n\r     index frequency :  %d  = %.3f us  \n\r", mfmf, mfm_f);
            speed = (1/(mfm_f/1000000))*60;
            printf("     Disk speed is:  %.2f RPM \n\r\n", speed);
            save_diskspeed_data();
            // *****************************************************************
            //
            //------------------------------------------------------------------+
            // Start collecting data                                            |
            //------------------------------------------------------------------+
            for(steps=0; steps<MAXCYL; steps++) {
                printf("\r      Cloning cylinder %d  ", steps );
                fflush(stdout); 
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x000F);            // Clear heads
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0001);             // Set head #1
                //while ((*(uint32_t *)PIO_2_addr & 0x0400));                     // Drive ready ? 
                usleep( 100*1000 );                                             // Wait a little ....
                //
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x000F);            // Clear heads
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0002);             // Set head #2
                //while ((*(uint32_t *)PIO_2_addr & 0x0400));                     // Drive ready ?
                usleep( 100*1000 );                                             // Wait a little ....
                //
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x000F);            // Clear heads
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0004);             // Set head #3
                //while ((*(uint32_t *)PIO_2_addr & 0x0400));                     // Drive ready ?
                usleep( 100*1000 );                                             // Wait a little ....
                //
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x000F);            // Clear heads
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0008);             // Set head #4
                //while ((*(uint32_t *)PIO_2_addr & 0x0400));                     // Drive ready ?
                usleep( 100*1000 );                                             // Wait a little ....
                //
                fflush(stdout);
                //
                //                                                              // ####################
                READ_drive_from_FPGA(SDRAM_adress);                             // ### FPGA-->Union ###
                //                                                              // ####################
                memcpy((void*)&gaps[steps][0], (void *)(XDPR_addr), nrofgaps);  // ####################
                //
                stepping();                                                     // Seek forward, one cylinder
                SDRAM_adress = SDRAM_adress + CYL_size;                         // Next Cylinder.   
            }           
            fflush(stdout);
            //
            //------------------------------------------------------------------+
            // Bring back in home-position                                      |
            //------------------------------------------------------------------+           
            printf("\n\r      back to home position" ); fflush(stdout);
            *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0100);                  // HIGH: Step backward = to Home
            while (!(*(uint32_t *)PIO_2_addr & 0x0400)) {
                stepping();
            }
            //
            //------------------------------------------------------------------+
            // Save data to Micro-SD-Card                                       |
            //------------------------------------------------------------------+                       
            printf ("\n\r      Save .mfm - data to SD-Card into file:  %s  \n\r", myfile4);
            PRESET_one_SECTOR();
            WRITE_to_SD_Card4();
            printf ("\n\r      Save .dsk - data to SD-Card into file:  %s  \n\r", myfile3);
            WRITE_to_SD_Card3();
            printf ("\n\r      Save .gap - data to SD-Card into file:  %s  \n\r", myfile5);
            WRITE_to_SD_Card5();
            //
            printf("\n\r   *********** Clone-Mode finished **********\n\r"); fflush(stdout);
            //
            //
        }else{
            //
            printf("\n\r");
            printf("      ******************************************\n\r");
            printf("      ************** Emulator-Mode *************\n\r");
            printf("      ******************************************\n\r"); 
            //
            OFFLINE = 0;                                                   // ONLINE-Mode           
            cl_mode=0;
            *(uint32_t *)PIO_2_addr = cl_mode;                             // Disable Clone mode            
            //
            //
            //*************************************************************
            // check for available disk-configuration file 
            //*************************************************************
            if(diskinfofile == FALSE) {                                   // Using default
                read_default_track();
            }else {                                                                   // Start normal
            //*******************************************************************
            //  Check for connected MFM controller , Power OK Signal @ I_ctrl[0]
            //*******************************************************************
                if(~( *(uint32_t *)PIO_1_addr) & 0x01) {
                    *(uint32_t *)PIO_1_addr = 0x0000;
                    printf("\n\r\x07\x1B[2J");                                             // VT100 EScape Sequenze : Clear_screen
                    printf("\n\r               System start not possible !      ");
                    printf("\n\r               No connection to controller    ");
                    printf("\n\r               Restart system and try again     ");
                    fflush(stdout);
                    while(1);
                } else {
                    if(~( *(uint32_t *)PIO_1_addr) & 0x20){
                        printf ("      Read MFM data file:  ");printf(" %s\n\r", myfile4 );
                        READ_from_SD_Card4();
                        printf ("      Read MFM gap  file:  ");printf(" %s\n\r", myfile5 );
                        READ_from_SD_Card5();
                    }
                }
            }       
            //      
            //cylinder = 100 ; SDRAM_adress= DPR_size *100;              // *** test/debug temorary ***
            //
            //          
            //                                                                      ####################
            WRITE_drive_to_FPGA(SDRAM_adress);//                                    ### Union-->FPGA ###
            memcpy((void *)(XDPR_addr), (void*)&gaps[cylinder][0], nrofgaps);//     ####################
            //                                                                      ####################
            //
                get_diskspeed_data();
                mfm_f = mfmf*0.0125;
                printf("\n\r      index frequency :  %d  = %.3f us  \n\r", mfmf, mfm_f);
                speed = (1/(mfm_f/1000000))*60;
                printf("      emulated disk speed is:  %.2f RPM \n\r", speed);
            //
            //
            mode = 0x4001;                                              // = start conditions set up
            *(uint32_t *)PIO_1_addr = (mode=mode|0x00A0);               // Output Enable + Drive Ready
            if(used_encoder == TRUE) {
                *(uint32_t *)PIO_1_addr = (mode=mode|0x0010);           // O_ctrl[4]: Used Encoder : 1 = MFM encoder
                printf("      mfm data ENcoding \n\r");
            } else {
                *(uint32_t *)PIO_1_addr = (mode=mode&~0x0010);          // O_ctrl[4]: Used Encoder : 0 = GAP encoder
                printf("      gap data ENcoding \n\r");
            }
            *(uint32_t *)PIO_1_addr = (mode=mode|0x0100);               // O_ctrl[8]: Set Drive to READY
            //
            //
            //==========================================================================================
            printf("\r\n ********** S T A R T ST-506/412/225 Emulator *********** \n\r");
            //==========================================================================================            
            //
            if(DEBUG == TRUE) {
                printf(" Started with operating mode:            ");
                print_binary_16bit_LSB(mode);printf("    \r\n\n\n");
            }
            fflush(stdout);         
            //
            //                                   §§§§§§§§§§§§§§§§§§§§§§§§§§
            //                                   §§§§§§§  MAIN LOOP §§§§§§§
            //                                   §§§§§§§§§§§§§§§§§§§§§§§§§§
            //
            //
            //while(1);                                                  // *** test/debug temorary ***
            //signal(SIGINT, sigintHandler);                             // Prevent abort by ctrl-C
            while(secwhile == 0) {                                       // Secondary while
                //
                //------------------------------------------------------------------+
                // check for drive command = step start @ I_ctrl[1]                 |
                //------------------------------------------------------------------+
                //        
                // First, copy/save data from DP-RAM's to SDRAM
                if((OFFLINE == FALSE) | (OFFMODE == TRUE)) {                                // ####################
                    READ_drive_from_FPGA(SDRAM_adress);                                     // ### FPGA-->Union ###
                    memcpy((void*)&gaps[cylinder][0], (void *)(XDPR_addr), nrofgaps);       // ####################
                }                                                                           // ####################             
                //
                if (( *(uint32_t *)PIO_1_addr) & 0x0002) {                                  // test @ I_ctrl[1]            
                    if(DEBUG == TRUE){ 
                        printf("\n\r Step request received: ");
                    }
                    // wait for Step-Cycle complete signal coming from sequencer @ I_ctrl[4]
                    while (!(*(uint32_t *)PIO_2_addr & 0x0010 ));
                    //
                    cylinder = *(uint32_t *)PIO_0_addr;                                     // receive new cylinder #
                    SDRAM_adress = cylinder * DPR_size;                                     // Calculate new SD-RAM address
                    if(DEBUG == TRUE) {
                        printf("\n\r  New cylinder address:         %d ", cylinder);
                    }
                    // restart cycle......
                    if((OFFLINE == FALSE) | (OFFMODE == TRUE)) {                            // ####################
                        WRITE_drive_to_FPGA(SDRAM_adress);                                  // ### Union-->FPGA ###
                        memcpy((void *)(XDPR_addr), (void*)&gaps[cylinder][0], nrofgaps);   // ####################
                    }                                                                       // ####################
                    //
                    Old_SDRAM_address = SDRAM_adress;
                    Old_cylinder = cylinder;
                    acknowledge();
                }                                                              // all done                  
                //
                //------------------------------------------------------------------+
                // check for power fail or reset                                    |
                //------------------------------------------------------------------+                                                           
                if (( ~ *(uint32_t *)PIO_1_addr & 0x8000 ) | ( ~ *(uint32_t *)PIO_1_addr & 0x0001 )) {
                    if( OFFLINE == FALSE ) {   
                        printf("    Key[1] / Power-fail   \n\r");
                        usleep( 500*1000 );
                        printf("\x1B[2J\n\r\x07        ......... Shutting down system .........\n\r");
                        READ_drive_from_FPGA(Old_SDRAM_address);
                        memcpy((void*)&gaps[Old_cylinder][0], (void *)(XDPR_addr), nrofgaps);
                        Old_cylinder = 0;
                        Old_SDRAM_address = 0;
                        //....save
                        WRITE_to_SD_Card4();
                        WRITE_to_SD_Card5();                        
                        *(uint32_t *)PIO_0_addr = 0x0000;                        // Clear PIO-0
                        *(uint32_t *)PIO_1_addr = 0x000C;                        // Clear PIO-1
                    } else {
                        *(uint32_t *)PIO_0_addr = 0x0000;                        // Clear PIO-0
                        *(uint32_t *)PIO_1_addr = 0x000C;                        // Clear PIO-1
                        printf("\x07\n\n\r        *** System switched down *** \n\r"); 
                    }
                    secwhile = 1;               
                }                       
            } // Secondary while
        }
        while ( ~ *(uint32_t *)PIO_1_addr & 0x8000 );   // Reset/Exit,       = Button 1 released
        usleep( 500*1000 );
        while ( ~ *(uint32_t *)PIO_1_addr & 0x4000 );   // Reconfig/Restart, = Button 2 released
        usleep( 500*1000 );
        printf("\x07\n\n\r  Press RESET/Button-1 for exit, Reconfig/Button-2 for restart  \n\r");
        priwhile = 2;
        while(priwhile == 2) {
            if ( ~ *(uint32_t *)PIO_1_addr & 0x4000 ) {  // Reconfig/Restart
                usleep( 500*1000 );
                secwhile = 0;
                priwhile = 0;
            }
            if ( ~ *(uint32_t *)PIO_1_addr & 0x8000 ) {  // Reset/EXit
                printf("\x07\n\n\r    Servus & Bye\n\r\n");
                fflush(stdout);
                usleep( 500*1000 );
                secwhile = 1;
                priwhile = 1;
            }
        }
    } // Primary while
    return 0; 
}