﻿/*
              *****************************************************************************
              *  Copyright (C)  by Reinhard Heuberger , info@pdp11gy.com                  *
              *                                                                           *
              *  All rights reserved.                                                     *
              *                                                                           *
              *  Redistribution and use in source and binary forms, with or without       *
              *  modification, are permitted provided that the following conditions       *
              *  are met:                                                                 *
              *                                                                           *
              *  1. Redistributions of source code must retain the above copyright        *
              *     notice, this list of conditions and the following disclaimer.         *
              *  2. Redistributions in binary form must reproduce the above copyright     *
              *     notice, this list of conditions and the following disclaimer in the   *
              *     documentation and/or other materials provided with the distribution.  *
              *  3. Neither the name of the author nor the names of its contributors may  *
              *     be used to endorse or promote products derived from this software     *
              *     without specific prior written permission.                            *
              *                                                                           *
              *****************************************************************************

                               MFM-DISK clone/Reader/tester ST506/412/225
                             Beta Version V1.0  for SoC HPS FPGA-environment
                                       ( Quartus Version 16.1 )
                                       based on DE10-Nano Board
                                 by: Reinhard Heuberger , www.PDP11GY.com
                          https://github.com/pdp11gy/SoC-HPS-based-MFM-disk-emulator


  
                                     Decoded data MAPPING mfm
                                     ************************

              / 3.290112 +------------------+      +------------------->256 byte impure area
             /           |   Cylinder #306  |      +------------+ 43008
   +--------+   3.279360 +------------------+     /|  Track #3  |>32256-43007
   |        |            |                  |    / |- - - - - - | 32256
   |   SD   |            .                  .   /  |  Track #2  |>21504-32255
   |  CARD  |            .                  .  /   |- - - - - - | 21504
   |        |            |                  | /    |  Track #1  |>10752-21503
   +--------+     10752  +------------------+/     |- - - - - - | 10752
             \           |    Cylinder #0   |      |  Track #0  |>00000-10751
              \   00000  +------------------+ - - -+------------+ 00000
              
              

                                     Decoded gap MAPPING gap 
                                     ***********************

              / 52.641.792 +------------------+      +------------------->256 byte impure area
             /             |   Cylinder #306  |      +------------+ 172032
   +--------+   52.469.760 +------------------+     /|  Track #3  |>129024-172031
   |        |              |                  |    / |- - - - - - | 129024
   |   SD   |              .                  .   /  |  Track #2  |>86016-129023 
   |  CARD  |              .                  .  /   |- - - - - - | 86016
   |        |              |                  | /    |  Track #1  |>43008-86015
   +--------+       172032 +------------------+/     |- - - - - - | 43008
             \             |    Cylinder #0   |      |  Track #0  |>00000-43007
              \     000000 +------------------+ - - -+------------+ 00000


    
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>

#include <sys/mman.h>
#include "hwlib.h"
#include "socal/socal.h"
#include "socal/hps.h"
#include "socal/alt_gpio.h"
#include "hps_0.h"
#include <signal.h>
//
//
void init_HW(void);
void init_DPRs(void);
void startup_leds(void);
void print_binary_16bit_LSB( unsigned short ibit16);
void stepping(void);
void WRITE_drive_to_FPGA(int point_to_cylinder);
void READ_drive_from_FPGA(int point_to_cylinder);
void WRITE_to_SD_Card1(int head);
void WRITE_to_SD_Card2(void);
void WRITE_to_SD_Card3(void);
void WRITE_to_SD_Card4(void);
void WRITE_to_SD_Card6(int head);
void WRITE_to_SD_Card7(int head);
void save_diskspeed_data(void);
void get_diskspeed_data(void);
void READ_from_SD_Card2(void);
void READ_from_SD_Card4(void);
//
//
typedef unsigned char byte;
//
#define HW_REGS_BASE ( ALT_STM_OFST )             // axi_lw
#define HW_REGS_SPAN ( 0x04000000 )               // Bridge span
#define HW_REGS_MASK ( HW_REGS_SPAN - 1 )
#define ALT_AXI_FPGASLVS_OFST (0xC0000000)        // axi_master
#define HW_FPGA_AXI_SPAN (0x40000000)             // Bridge span
#define HW_FPGA_AXI_MASK ( HW_FPGA_AXI_SPAN - 1 ) //
//
#define CYL_size   43008         // One cylinder size, byte
#define DPR_size   43008         // mfm data: Dual-Portet-RAM size
#define ST506_size 153           // ST506 = 153 cylinder (  5.40 MB )
#define ST412_size 306           // ST412 = 306 cylinder ( 10.16 MB )
#define ST225_size 615           // ST225 = 615 Cylinder ( 20.42 MB )
#define nrofgaps   172032        // number of MFM-gaps per cylinder
#define XDPR_size  172032        // gap data: Dual ported RAM size 
#define TRUE  1
#define FALSE 0
//
unsigned short int header_index =   7;                             // Header index = 7 (word) (15=byte)
unsigned short int data_start =    19;                             // + 12
unsigned short int data_CRC =     147;                             //    + 128
unsigned short int ST_unit  =       0;                             // current selected ST unit-number
unsigned short int ST_type  =       0;                             // Drive-Type
unsigned short int CYL_P = 15, HD_P = 17, SEC_P = 16;              // point to cylinder,head, sector
unsigned short int DataAM   =       0xA1F8;                        // Indicator Pattern before Data Field
unsigned char DataAM_lsb, DataAM_msb;                              //  split in 2 bytes
//
short int mode=0;                                                  // System operating mode >general
short int cl_mode=0;                                               // System operating mode >clone-mode
unsigned char FOUND=0;                                             // drive found , clone mode
unsigned char DEBUG=0;                                             // DEBUG PURPOSE
unsigned char OFFLINE=0;                                           // online/offline mode
unsigned char OFFMODE=0;                                           // full/simple offline mode
//
/*        *********************** Global Definitions **********************        */
//
//+++++++++++++++++++++++++++++++ MFM data = UNION's +++++++++++++++++++++++++++++++++++++++++++++++++++
//
union std {                                  // ****** ST-506/412 sector ************
       unsigned char  st_c[512];             // Access to one sector via 512 bytes or
       unsigned short st_i[256];             // 256 16Bit words.
       unsigned int   st_l[128];
};
union  std SECTOR __attribute__ ((aligned(4)));                    // define a union of type SECTOR
union  std *u_stptr;                                               // pointer to union.
//
//                 ****** ST-412/506 u. ST225 @ SD-RAM/=union ********
//                     Virtual access to 306 cylinders(head 0 to 3)
//                     4heads: = 1 Cylinder =    42240 byte 
//                     ST506 , 153 Cylinder =  6462720 byte
//                     ST412 , 306 Cylinder = 12925440 byte
//                     ST225 , 615 Cylinder = 25977600 byte
union mfm {
       unsigned char  st_drive_c[25977600];    // current maximal memory usage 
       unsigned short st_drive_i[12988800];
       unsigned int   st_drive_l[6494400]; 
};
union  mfm MFMDISK __attribute__ ((aligned(4)));                   // define a union of type MFMDISK
union  mfm *u_st_drive_ptr;                                        // pointer to union
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//+++++++++++++++++++++++++++++++ gap data = byte arry +++++++++++++++++++++++++++++++++++++++++++++++++
//
unsigned char gaps[nrofgaps];
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//
int SDRAM                   = 26449920;                            // maximum used bytes SD-RAM
int SECsize                 = 512;                                 // Sector size , Byte
unsigned short MAXCYL       = 615;                                 // cylinder, ST412/ST506
int mfmf=0, mfmw=0;                                                // index frequency and puls-width
//
char myfile2[80];
char myfile1[80];
char myfile3[80];
char myfile4[80];
char myfile5[80];
char myfile6[80];
char myfile7[80];
char info[10];
//
//
//------------------------------------------------------------------------------------------------------
int fd;                                           // Hold FPGA address
void *virtual_base;                               // Virtual axi-lw addr that maps to physical
void *axi_virtual_base;                           // Virtual axi-master addr that maps to physical
void *PIO_0_addr;                                 // PIO-0 address
void *PIO_1_addr;                                 // PIO-1 address
void *PIO_2_addr;                                 // PIO-2 address
void *PIO_3_addr;                                 // PIO-3 address
void *PIO_4_addr;                                 // PIO-4 address
void *DPR;                                        // #1, Dual Ported Ram address
void *DPR_addr;                                   // #1, Dual Ported Ram address with AXI-Master
void *XDPR;                                       // #2, Dual Ported Ram address
void *XDPR_addr;                                  // #2, Dual Ported Ram address with AXI-Master
//void *UART0;                                    // UART_0 address
//------------------------------------------------------------------------------------------------------
//
unsigned char priwhile = 0;
unsigned char secwhile = 0;
//
//
void init_HW(void)
{
  //---------------------------------------------------------------------------------------------------
  // === get FPGA addresses ===
  // Open /dev/mem
  if( ( fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
        printf( "ERROR: could not open \"/dev/mem\"...\n" );
  return; }
  //---------------------------------------------------------------------------------------------------
  // Get virtual addr that maps to physical
  virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );
  if( virtual_base == MAP_FAILED ) {
        printf( "ERROR: mmap() failed...\n" );
        close( fd );
  return; }
  axi_virtual_base = mmap( NULL, HW_FPGA_AXI_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, ALT_AXI_FPGASLVS_OFST );
  //----------------------------------------------------------------------------------------------------
  //
  // Get the addresses that maps to the FPGA control
  PIO_0_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + PIO_0_BASE )
                                & ( unsigned long)( HW_REGS_MASK ) );
  PIO_1_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + PIO_1_BASE )
                                & ( unsigned long)( HW_REGS_MASK ) );
  PIO_2_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + PIO_2_BASE )
                                & ( unsigned long)( HW_REGS_MASK ) );
  PIO_3_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + PIO_3_BASE )
                                & ( unsigned long)( HW_REGS_MASK ) );
  PIO_4_addr = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + PIO_4_BASE )
                                & ( unsigned long)( HW_REGS_MASK ) );
  //
  DPR =  virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + DPR_BASE )
                      & ( unsigned long)( HW_REGS_MASK ) );
  DPR_addr =   axi_virtual_base + ( ( unsigned long  )( DPR_BASE ));  // This works with DPR !!!
  //
  XDPR =  virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + XDPR_BASE )
                      & ( unsigned long)( HW_REGS_MASK ) );
  XDPR_addr =   axi_virtual_base + ( ( unsigned long  )( XDPR_BASE ));  // This works with DPR !!!
  //
  //  
  //UART0 = virtual_base + ( ( unsigned long  )( ALT_LWFPGASLVS_OFST + UART_0_BASE )
  //                    & ( unsigned long)( HW_REGS_MASK ) );
  if( virtual_base == MAP_FAILED ) {
        printf( "ERROR: mmap() failed...\n" );
        close( fd );
        return;
  }
  //
  //-----------------------------------------------------------------------------------------------------
  //
}
//
void init_DPRs(void) {
    //
    int imfm, igap; 
    int mfm, gap;
    //------------------------------------------------ Preset start
    mfm = CYL_size/4;
    gap = nrofgaps/4;
    strcat( info, " track_1 " );
    for (imfm = 0; imfm < DPR_size; imfm++ ){
        MFMDISK.st_drive_c[imfm] = 'U';                 // = 'U'; = 0x55;       
    }   
    for (igap = 0; igap < nrofgaps; igap++ ){
        gaps[igap] = 0xFF;                             // = 0xFF;
    }   
    memcpy(MFMDISK.st_drive_c + mfm-10, info, sizeof(info));
    memcpy(gaps + gap-9, info, sizeof(info));
    // 
    mfm = mfm + CYL_size/4;
    gap = gap + nrofgaps/4;
    info[7] = '2';
    memcpy(MFMDISK.st_drive_c + mfm-10, info, sizeof(info));
    memcpy(gaps + gap-9, info, sizeof(info));
    //
    mfm = mfm + CYL_size/4;
    gap = gap + nrofgaps/4;
    info[7] = '3';
    memcpy(MFMDISK.st_drive_c + mfm-10, info, sizeof(info));
    memcpy(gaps + gap-9, info, sizeof(info));
    //
    mfm = mfm + CYL_size/4;
    gap = gap + nrofgaps/4;
    info[7] = '4';
    memcpy(MFMDISK.st_drive_c + mfm-10, info, sizeof(info));
    memcpy(gaps + gap-9, info, sizeof(info));
    //
    mode = 0x4001;  
    *(uint32_t *)PIO_1_addr = mode; //  = ENABLE interface
    memcpy((void *)(XDPR_addr), &gaps[0], nrofgaps);
    memcpy((void *)(DPR_addr),  &MFMDISK.st_drive_i[0], CYL_size);
    //------------------------------------------------Preset End
    //
}
//
//
void startup_leds(void)
{
int loop_count;
int led_direction;
int led_mask;
loop_count = 0;
led_mask = 0x01;
led_direction = 0; // 0: left to right direction
    //
    while(loop_count < 3 )  {
      *(uint32_t *)PIO_0_addr = led_mask;
      usleep( 20*1000 );
      if (led_direction == 0){
            led_mask <<= 1;
            if (led_mask == (0x01 << (PIO_0_DATA_WIDTH-1)))
                 led_direction = 1;
        }else{
            led_mask >>= 1;
            if (led_mask == 0x01){
                led_direction = 0;
                loop_count++;
            }
        }
    }
}
//
//
void print_binary_16bit_LSB( unsigned short ibit16)
// Representation: LSB on right site ( PDP-11 like)
{
 int i;
  for (i = 0; i < 16; i++ ){
       if(0x8000 & ibit16 ) {               // Test Bit 15
          printf("1");
          }
           else {
              printf("0");
           }
   ibit16 = ibit16 << 1;
  }
}
//
//
void stepping(void){
    //
    // Generate 1 Step puls. Note:
    //IOWR_ALTERA_AVALON_PIO_DATA(PIO_2_BASE, (cl_mode=cl_mode|0x0100));      // HIGH: Step backward = to Home
    //IOWR_ALTERA_AVALON_PIO_DATA(PIO_2_BASE, (cl_mode=cl_mode&~0x0100));     // LOW:  Step forward  = to Spindl
    //
    *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0200);
    usleep( 10*1000 ); //
    *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0200);
    usleep( 10*1000 ); //
}
//
//
void WRITE_to_SD_Card1(int head){                             // ***** .mfm track/head1  *****
    //
    FILE    *fptr;
    int i=head-1;
    //
    fptr = fopen(myfile1, "wb");
    if(fptr == NULL) {
        printf ("\n\r\x07 ERROR open/write image file %s \n\r", myfile1);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    printf("\r       Decoded data      @head%d save into file:  %s  \n\r", head,myfile1);
    //
    fwrite((void*)&MFMDISK.st_drive_c[i*(CYL_size/4)], 1 , CYL_size/4, fptr );
    //
    fclose(fptr);
}
//
void WRITE_to_SD_Card2(void){                                 // ***** .mfm cylinder  *****
    //
    FILE    *fptr;
    //
    fptr = fopen(myfile2, "wb");
    if(fptr == NULL) {
        printf ("\n\r\x07 ERROR open/write image file %s \n\r", myfile2);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    //
    fwrite((void*)&MFMDISK.st_drive_c[0], 1 , CYL_size, fptr );
    //
    fclose(fptr);
}
//
void WRITE_to_SD_Card3(void){                                 // ***** .dsk  *****
    //
    FILE    *fptr;
    int i=0, diff=0 , count=0;
    //
    fptr = fopen(myfile3, "wb");
    if(fptr == NULL) {
        printf ("\n\r\x07 ERROR open/write image file %s \n\r", myfile3);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    for ( i = 0; i < CYL_size ; i++) {
        //printf ("\n\r Pattern: 0x%04X", MFMDISK.st_drive_i[i]);
        if((MFMDISK.st_drive_c[i] == DataAM_msb) & (MFMDISK.st_drive_c[i+1] == DataAM_lsb) || 
           (MFMDISK.st_drive_c[i] == ~DataAM_msb) & (MFMDISK.st_drive_c[i+1] == ~DataAM_lsb) ){
            count++;
            printf ("\n\r found: DataAM_msb 0x%02X  DataAM_lsb 0x%02X @ %d  Nr.: %d  Gap: %d", DataAM_msb, DataAM_lsb, i, count, i-diff);
            diff=i;
            fwrite((void*)&MFMDISK.st_drive_c[i+2], 1 , 512, fptr );
            i=i+SECsize+5;
        }
    }
    fflush(stdout);
    fclose(fptr);
}
//
void WRITE_to_SD_Card4(void){                               // ***** .gap  *****
    //
    // wirte 1 cylinder of .gap data
    //
    FILE    *fptr;
    //
    fptr = fopen(myfile4, "wb");
    if(fptr == NULL) {
        printf ("\n\r\x07 ERROR open/write image file %s \n\r", myfile4);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    fwrite((void*)&gaps[0], 1 , nrofgaps, fptr );
    fclose(fptr);
}
//
void WRITE_to_SD_Card6(int head){                         // ***** .mfm track/head1  *****
    //
    FILE    *fptr;
    int start,end;
    int i=30, count=0;
    start = (head-1)*(CYL_size/4)+30;
    end   = ((head-1)*(CYL_size/4))+(CYL_size/4);
    //
    fptr = fopen(myfile6, "wb");
    if(fptr == NULL) {
        printf ("\n\r\x07 ERROR open/write image file %s \n\r", myfile6);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    //printf("\n\r     #1: %d    #2: %d  \n\r",start,end );  
    printf("\r       user raw data     @head%d save into file:  %s  \n\r", head,myfile6);
    for ( i = start; i < end ; i++) {
        if((MFMDISK.st_drive_c[i] == DataAM_msb) & (MFMDISK.st_drive_c[i+1] == DataAM_lsb) || 
           (MFMDISK.st_drive_c[i] == ~DataAM_msb) & (MFMDISK.st_drive_c[i+1] == ~DataAM_lsb) ){
            count++;
            fwrite((void*)&MFMDISK.st_drive_c[i+2], 1 , 512, fptr );
            i=i+SECsize+40;
        }           
    }
    printf ("\r       Track/head %d : found %d matches\n\r",head,count);
    //
    fclose(fptr);
}
//
void WRITE_to_SD_Card7(int head){                         // ***** .gap track/head1  *****
    //
    FILE    *fptr;
    int i=head-1;
    //
    fptr = fopen(myfile7, "wb");
    if(fptr == NULL) {
        printf ("\n\r\x07 ERROR open/write image file %s \n\r", myfile7);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    printf("\r       Recorded Gap data @head%d save into file:  %s  \n\r", head,myfile7);
    //
    fwrite((void*)&gaps[i*(nrofgaps/4)], 1 , nrofgaps/4, fptr );
    //
    fclose(fptr);
}
//
//
void save_diskspeed_data(void){
    FILE    *fptr;
    //
    fptr = fopen(myfile5, "wb");
    if(fptr == NULL) {
        printf ("\n\r\x07 ERROR open/write disk speed data file %s \n\r", myfile5);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    fprintf(fptr , "%d,%d\n", mfmf,mfmw);
    fclose(fptr);
    
}
//
//
void get_diskspeed_data(void){
    FILE    *fptr;
    int temp1, temp2;
    //
    fptr = fopen(myfile5, "rb");
    if(fptr == NULL) {
        printf ("\n\r\x07 ERROR open/write disk speed data file %s \n\r", myfile5);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    fscanf(fptr, "%d, %d",&temp1,&temp2);
    fclose(fptr);
    mfmf = temp1;
    mfmw = temp2;
}
//
//
void READ_from_SD_Card2(void){                        // ***** .mfm cylinder  *****
    //
    FILE    *fptr;
    int i=0;
    //
    fptr = fopen(myfile2, "rb");
    if(fptr == NULL) {
        printf ("\n\r\x07 ERROR open/read image file %s \n\r", myfile2);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    //
    fread((void*)&MFMDISK.st_drive_c[i], 1 , CYL_size, fptr );
    //
    fclose(fptr);
}
//
void READ_from_SD_Card4(void){                        // ***** .gap  *****
    //
    //
    FILE    *fptr;
    //
    fptr = fopen(myfile4, "rb");
    if(fptr == NULL) {
        printf ("\n\r\x07 ERROR open/read image file %s \n\r", myfile4);
        *(uint32_t *)PIO_1_addr = 0x0000;
        while(1);
    }
    fread((void*)&gaps[0], 1 , nrofgaps, fptr );
    fclose(fptr);
}
//
//
void WRITE_drive_to_FPGA(int point_to_cylinder){
    //
    // This routine writes one cylinder from union MFMDISK.st_drive_i to FPGA/DP-RAM
    //                               ####################
    //                               ### Union-->FPGA ###
    //                               ####################
    //
    memcpy((void *)(DPR_addr), &MFMDISK.st_drive_i[point_to_cylinder], CYL_size);
    //
}
//
void READ_drive_from_FPGA(int point_to_cylinder){
    //
    // This routine reads one cylinder from FPGA/DP-RAM into union MFMDISK.st_drive_i
    //                               ####################
    //                               ### FPGA-->Union ###
    //                               ####################
    //
    //
    memcpy(&MFMDISK.st_drive_i[point_to_cylinder], (void *)(DPR_addr), CYL_size);
    //
}
//
//
//
//
//                                            §§§§§§§§§§§§§§§§§§§§§§§§§§
//                                            §§§§§§§    MAIN    §§§§§§§
//                                            §§§§§§§§§§§§§§§§§§§§§§§§§§
//
int main()
{
    int steps, tocyl, tohead=1, trigger;
    int SDRAM_adress = 0; 
    float speed, mfm_f, mfm_w;
    char buffer[10];
    char extension[6] =  ".mfm";
    char extension3[6] = ".dsk";
    char extension4[6] = ".gap";
    strcat( myfile5, "diskspeed.inf" );
    //
    FOUND   = 0;
    cl_mode = 0;
    mode    = 0;
    init_HW();
    *(uint32_t *)PIO_0_addr = mode;                     // Clear PIO-0
    *(uint32_t *)PIO_1_addr = mode;                     // Clear PIO-1
    *(uint32_t *)PIO_2_addr = cl_mode;                  // Clear PIO-2
    init_DPRs();
    //
    while(priwhile == 0) {                              // Primary while
        //
        printf("\n\r\x1B[2J");
        printf("         ****** MFM-DISK read + test  @ Soc/HPS *******                \n\r");
        printf("         READ one Cylinder/Track and save it to SD card                \n\r");
        printf("            DE10-Nano ST-506/412/225  Version  V1.0                    \n\r");
        printf("         *********************|*************************               \n\r");
        printf("                     (c) WWW.PDP11GY.COM                               \n\r");
        //
        startup_leds();
        //
        // >>>>>>>>>>>>>>>>>> Check for debug mode <<<<<<<<<<<<
        if (( *(uint32_t *)PIO_2_addr) & 0x0040) {
           DEBUG = 1;
           printf ("\n\r              >>>>>> DEBUG-MODE = ON <<<<<<");
        } else {
           DEBUG = 0;
           printf ("\n\r              >>>>>> DEBUG-MODE = OFF <<<<<");
        }
        //
        //
        ST_type = ( *(uint32_t *)PIO_2_addr) &~0xFFF0;
        switch(ST_type) {
            case 0x0000:
                SDRAM = 6374400;
                MAXCYL = ST506_size;
                SECsize = 512;
                strcat( myfile1, "mfm-data@head=track-X_cyl-" );
                strcat( myfile2, "ST506_mfm-data@cylinder_" );
                strcat( myfile3, "ST506_raw-data@cylinder_" );
                strcat( myfile4, "ST506_gap-data@cylinder_" );
                strcat( myfile6, "raw-data@head=track-X_cyl-" );
                strcat( myfile7, "gap-data@head=track-X_cyl-");
                printf ("\n\r              >>>> Device Type = ST506 <<<<\n\r");
                DataAM = 0xA5F8;
                break;
            case 0x0001:
                SDRAM = 12774400;
                MAXCYL = ST412_size;
                SECsize = 512;
                strcat( myfile1, "mfm-data@head=track-X_cyl-" );
                strcat( myfile2, "ST412_mfm-data@cylinder_" );
                strcat( myfile3, "ST412_raw-data@cylinder_" );
                strcat( myfile4, "ST412_gap-data@cylinder_" );
                strcat( myfile6, "raw-data@head=track-X_cyl-" );
                strcat( myfile7, "gap-data@head=track-X_cyl-");
                printf ("\n\r              >>>> Device Type = ST412 <<<<\n\r");
                DataAM = 0xA5F8;
                break;
            case 0x0002:
                SDRAM = 25625600;
                MAXCYL = ST225_size;
                SECsize = 512;
                strcat( myfile1, "mfm-data@head=track-X_cyl-" );
                strcat( myfile2, "ST225_mfm-data@cylinder_" );
                strcat( myfile3, "ST225_raw-data@cylinder_" );
                strcat( myfile4, "ST225_gap-data@cylinder_" );
                strcat( myfile6, "raw-data@head=track-X_cyl-");
                strcat( myfile7, "gap-data@head=track-X_cyl-");
                printf ("\n\r             >>>> Device Type = ST225 <<<<\n\r");
                DataAM = 0xA5F8;
                break;
            default:
                SDRAM = 12774400;
                MAXCYL = ST412_size;
                SECsize = 512;
                strcat( myfile1, "mfm-data@head=track-X_cyl-" );
                strcat( myfile2, "ST412_mfm-data@cylinder_" );
                strcat( myfile3, "ST412_raw-data@cylinder_" );
                strcat( myfile4, "ST412_gap-data@cylinder_" );
                strcat( myfile6, "raw-data@head=track-X_cyl-");
                strcat( myfile7, "gap-data@head=track-X_cyl-");
                printf ("\n\r              ****     Using default   ****");
                printf ("\n\r              >>>> Device Type = ST412 <<<<\n\r");
                DataAM = 0xA5F8;
                break;
        }
        fflush(stdout);
        *(uint32_t *)PIO_3_addr = DataAM ;
        //
        //
        //----------------------------------------------------------------------------------------------------
        //
        if (~( *(uint32_t *)PIO_1_addr) & 0x0020) {
                printf("\n\r**************** temporary emulator mode  **************\n\r");
				//
                cl_mode= 0x0000;
				//mode   = 0x0001;
                get_diskspeed_data();
                mfm_f = mfmf*0.0125;
                printf("\n\r      index frequency :  %d  = %.3f us  \n\r", mfmf, mfm_f);
                speed = (1/(mfm_f/1000000))*60;
                printf("      emulated disk speed is:  %.2f RPM \n\r", speed);
                //
                *(uint32_t *)PIO_2_addr = cl_mode;                            // Disable Clone mode
				//*(uint32_t *)PIO_1_addr = mode;                               // ENABLE interface
                //---------------------------------------------------------------------------------------------
                *(uint32_t *)PIO_1_addr = (mode=mode|0x0200);                 // set to index pulse setup
                usleep( 500*1000 );
                *(uint32_t *)PIO_4_addr = mfmw;
                usleep( 500*1000 );
                *(uint32_t *)PIO_1_addr = (mode=mode&~0x0200);                // set to index frequency setup
                usleep( 500*1000 );
                *(uint32_t *)PIO_4_addr = mfmf; 
                //---------------------------------------------------------------------------------------------
                printf("\n\r       Cylinder - nummer eingeben:  ");
                scanf("%d", &tocyl);
                sprintf(buffer, "%d", tocyl);
                strcat(myfile2, buffer);
                strcat(myfile4, buffer);
                strcat(myfile2, extension);
                strcat(myfile4, extension4); 
                //strcat(myfile6, extension4);
                printf ("            Read MFM data file:  ");printf(" %s\n\r", myfile2 );
                READ_from_SD_Card2();
                WRITE_drive_to_FPGA(SDRAM_adress);
                //
                printf ("            Read MFM gap  file:  ");printf(" %s\n\r", myfile4 );
                READ_from_SD_Card4();
                memcpy((void *)(XDPR_addr), (void*)&gaps[0], nrofgaps);
                //
                mode = 0x4001;                                                 // = start conditions set up
                *(uint32_t *)PIO_1_addr = mode;                                // Start, Step #1 of 2 = ENABLE interface
                *(uint32_t *)PIO_1_addr = (mode=mode|0x00A0);                  // Output Enable + Drive Ready
                *(uint32_t *)PIO_1_addr = (mode=mode|0x0100);                  // O_ctrl[8]: Set Drive to READY
                *(uint32_t *)PIO_1_addr = (mode=mode&~0x0010);                 // O_ctrl[4]: Used Encoder : 0 = GAP encoder
                printf(" Started with operating mode:            ");
                print_binary_16bit_LSB(mode);printf("    \r\n\n\n");
                while(1);
        }
        //
        //-----------------------------------------------------------------------------------------------------
        //
        mode = 0x4001;                                                        // ***********************
        *(uint32_t *)PIO_1_addr = mode;                                       // Disable Emulator mode *
        //                                                                    // ***********************
        //
        // Set Start-condition: CL_TRI_control
        cl_mode=0x8000;                                                       // Preset = Enable Clone mode
        *(uint32_t *)PIO_2_addr = cl_mode;                                    // Start conditions
        *(uint32_t *)PIO_1_addr = mode;                                       // ENABLE interface
        *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0001);                   // Set head #1
        *(uint32_t *)PIO_1_addr = (mode=mode&~0x0008);                        // Disable  Clone Sequenzer
        //*(uint32_t *)PIO_1_addr = (mode=mode|0x0008);                       // Enable   Clone Sequenzer
        //
        if(DEBUG == TRUE) {
            printf("\n\r      Anzahl der Cylinder: %d ", MAXCYL );
        }
        //
        //---------------------------------------------------------------------+
        // First: find configured device number                                |
        //---------------------------------------------------------------------+
        FOUND = FALSE;
        if(FOUND == FALSE) {
            printf("\n\r      Drive_select #0 " );
            *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0010);   //#0
            usleep( 200*1000 );
            if (( *(uint32_t *)PIO_2_addr) & 0x1000) {
                printf(" DRV_SLCTD = HIGH " );
                FOUND=TRUE;
            }else{
                printf(" DRV_SLCTD = LOW  " );
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0010);
            }
        }
        // ------------------------------------------------------------------
        if(FOUND == FALSE) {
            printf("\n\r      Drive_select #1 " );
            *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0020);   //#1
            usleep( 200*1000 );
            if (( *(uint32_t *)PIO_2_addr) & 0x1000) {
                printf(" DRV_SLCTD = HIGH " );
                FOUND=TRUE;
            }else{
                printf(" DRV_SLCTD = LOW  " );
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0020);
            }
        }
        // ------------------------------------------------------------------
        if(FOUND == FALSE) {
            printf("\n\r      Drive_select #2 " );
            *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0040);   //#2
            usleep( 200*1000 );
            if (( *(uint32_t *)PIO_2_addr) & 0x1000) {
                printf(" DRV_SLCTD = HIGH " );
                FOUND=TRUE;
            }else{
                printf(" DRV_SLCTD = LOW  " );
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0040);
            }
        }
        // ------------------------------------------------------------------
        if(FOUND == FALSE) {
            printf("\n\r      Drive_select #3 " );
            *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0080);   //#3
            usleep( 200*1000 );
            if (( *(uint32_t *)PIO_2_addr) & 0x1000) {
                printf(" DRV_SLCTD = HIGH " );
                FOUND=TRUE;
            }else{
                printf(" DRV_SLCTD = LOW  " );
                *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0080);
            }
        }
        //
        usleep( 200*1000 );
        //-------------------------------------------------------------------
        if (FOUND == FALSE ){
            printf("\n\r\n      !!! ERROR:  NO disk found  !!! \n\r" );
            fflush(stdout);
            //while(1);
        }
        //-------------------------------------------------------------------
        if (( *(uint32_t *)PIO_2_addr) & 0x0100) {
            printf("\n\r      READY =      HIGH " );
        }else{
            printf("\n\r      READY =      LOW  " );
        }
        //-------------------------------------------------------------------
        if (( *(uint32_t *)PIO_2_addr) & 0x0800) {
            printf("\n\r      SEEK_cmplt = HIGH " );
        }else{
            printf("\n\r      SEEK_cmplt = LOW  " );
        }
        //-------------------------------------------------------------------
        if (( *(uint32_t *)PIO_2_addr) & 0x0400) {
          printf("\n\r      TRACK_0 =    HIGH " );
        }else{
          printf("\n\r      TRACK_0 =    LOW  " );
        }
        //-------------------------------------------------------------------
        if (( *(uint32_t *)PIO_2_addr) & 0x1000) {
          printf("\n\r      DRV_SLCTD =  HIGH " );
        }else{
          printf("\n\r      DRV_SLCTD =  LOW  " );
        }
        //
        //------------------------------------------------------------------+
        // Check for Drive READY @ CL_I[8] = 0x0100                         |
        //------------------------------------------------------------------+
        if (( *(uint32_t *)PIO_2_addr) & 0x0100) {
            printf("\n\r      Drive = ready" );
        }else{
            printf("\n\r Drive is NOT ready, wait ...." );
            while (!(*(uint32_t *)PIO_2_addr & 0x0400)) {
                usleep( 500*1000 );
                printf(".");
                fflush(stdout);
            }
            printf("\n\r      Drive = ready, continue" );
        }
        //
        //------------------------------------------------------------------+
        // Check & if necessary, adjust to home position @ CL_I[10]=0x0400  |
        //------------------------------------------------------------------+
        if (( *(uint32_t *)PIO_2_addr) & 0x0400) {
            printf("\n\r      Drive is @ home" );
            fflush(stdout);
        }else{
            printf("\n\r      Drive is NOT @ home" );
            fflush(stdout);
            *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0100);             // HIGH: Step backward = to Home
            while (!(*(uint32_t *)PIO_2_addr & 0x0400)) {                   // Step back, until
                stepping();                                                 // track0 signal receiving
            }
            printf("\n\r    Drive positioned to home" );
            fflush(stdout);
            *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x0100);            // LOW:  Step forward  = to Spindl
        }
        printf("\n\r\n" );
        //      
        //------------------------------------------------------------------+
        // Start collecting data         |||||||||||||||||||||||||          |
        //------------------------------------------------------------------+
        printf("\n\r       Cylinder - nummer eingeben:  ");
        scanf("%d", &tocyl);
        printf("\n\r       Trigger DataAM , (4Hex, like A5F8)  :");
        scanf("%4x", &trigger);
        DataAM = trigger;
        *(uint32_t *)PIO_3_addr = DataAM ;
        //
        DataAM_lsb = (unsigned)DataAM & 0xff;     // mask the lower 8 bits
        DataAM_msb = (unsigned)DataAM >> 8;       // shift the higher 8 bits
        //
        printf("\n\r   Cylinder: %d ,Trigger DataAM: lsb : 0x%02X  msb: 0x%2X  ", tocyl,DataAM_msb,DataAM_lsb );
        printf("\n\r\n      ************ Step to Cylinder %d ", tocyl);
        fflush(stdout);
        for(steps=0; steps<tocyl; steps++) {
            stepping();
            usleep( 1000 );
        }
        printf(" done ***********\n\r\n");
        fflush(stdout);
        *(uint32_t *)PIO_1_addr = (mode=mode|0x0008);                   // ****** Enable   Clone Sequenzer ******
        usleep( 1500*1000 );
        //
        //=====================================================================
        //      
        //
        printf("\r         Select Head 1 ");fflush(stdout);
        *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x000F);            // Clear heads
        *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0001);             // Set head #1
        usleep( 50*1000 );
        while ((*(uint32_t *)PIO_2_addr & 0x0400));                     // Drive ready ?
        usleep( 1000*1000 );
        //
        printf("\r         Select Head 2 ");fflush(stdout);
        *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x000F);            // Clear heads
        *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0002);             // Set head #2
        usleep( 50*1000 );
        while ((*(uint32_t *)PIO_2_addr & 0x0400));                     // Drive ready ?
        usleep( 1000*1000 );
        //
        printf("\r         Select Head 3 ");fflush(stdout);
        *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x000F);            // Clear heads
        *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0004);             // Set head #3
        usleep( 50*1000 );
        while ((*(uint32_t *)PIO_2_addr & 0x0400));                     // Drive ready ?
        usleep( 1000*1000 );
        //
        printf("\r         Select Head 4 \r\n\n");fflush(stdout);
        *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x000F);            // Clear heads
        *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0008);             // Set head #4
        usleep( 50*1000 );
        while ((*(uint32_t *)PIO_2_addr & 0x0400));                     // Drive ready ?
        usleep( 1000*1000 );
        //
        //
		*(uint32_t *)PIO_1_addr = (mode=mode&~0x0008);                  // Disable  Clone Sequenzer
        //
        //                                                              // ####################
        READ_drive_from_FPGA(SDRAM_adress);                             // ### FPGA-->Union ###
        //                                                              // ####################      
        memcpy((void*)&gaps[0], (void *)(XDPR_addr), nrofgaps);         // ####################
        //
		*(uint32_t *)PIO_1_addr = (mode=mode|0x0008);                   // Enable   Clone Sequenzer
        //
        //------------------------------------------------------------------+
        // Save data of 1 cylinder to Micro-SD-Card                         |
        //------------------------------------------------------------------+
        sprintf(buffer, "%d", tocyl);
        strcat(myfile1, buffer);
        strcat(myfile2, buffer);
        strcat(myfile3, buffer);
        strcat(myfile4, buffer);
        strcat(myfile6, buffer);
        strcat(myfile7, buffer);
        strcat(myfile1, extension);
        strcat(myfile2, extension);
        strcat(myfile3, extension3);
        strcat(myfile4, extension4);
        strcat(myfile6, extension3);
        strcat(myfile7, extension4);
        //
        //
        printf ("\n\r      Save MFM-gaps    data into file: %s", myfile4);
        printf ("\n\r      Save RAW-image   data into file: %s", myfile3);
        printf ("\n\r      Save MFM-decoded data into file: %s\n\r", myfile2);
        //
        WRITE_to_SD_Card2();                                            // ***** .mfm cylinder  *****
        WRITE_to_SD_Card4();                                            // ***** .gap cylinder  *****
        WRITE_to_SD_Card3();                                            // ***** .dsk cylinder  *****
        //
        // ***************************************************************
        *(uint32_t *)PIO_1_addr = (mode=mode|0x0200);                   // setup index pulse-width measurement
        usleep( 500*1000 );
        mfmw = *(uint32_t *)PIO_4_addr;
        mfm_w = mfmw*0.0125;
        printf("\n\n\n\r      index puls-width :  %d  =  %.3f us  ", mfmw, mfm_w);
        fflush(stdout);
        *(uint32_t *)PIO_1_addr = (mode=mode&~0x0200);                  // setup index frequency measurement
        usleep( 500*1000 );
        mfmf = *(uint32_t *)PIO_4_addr;
        mfm_f = mfmf*0.0125;
        printf("\n\r      index frequency :  %d  = %.3f us  \n\r", mfmf, mfm_f);
        speed = (1/(mfm_f/1000000))*60;
        printf("      Disk speed is:  %.2f RPM \n\r", speed);
        // *****************************************************************
        //
        save_diskspeed_data();
        //
        //
        while(tohead != 0) {
            printf("\n\r       Select haed, 1 to 4 ( 0=exit/5=set DataAM)  : ");
            scanf("%d", &tohead);
            switch(tohead) {
                case 1:
                    *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x000F);     // Clear heads
                    *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0001);      // Set head #1
                    while ((*(uint32_t *)PIO_2_addr & 0x0400));              // Drive ready ?
                    usleep( 1000*1000 );
                    READ_drive_from_FPGA(SDRAM_adress);                      // ### FPGA-->Union ###
                    myfile1[20] ='1';
                    WRITE_to_SD_Card1(tohead);                               // ** .mfm track @ head1  **
                    myfile7[20] ='1';
                    WRITE_to_SD_Card7(tohead);                               // ** .gap track @ head1  **
                    myfile6[20] ='1';
                    WRITE_to_SD_Card6(tohead);                               // ** .dsk track @ head1  **
                break;
                case 2:
                    *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x000F);     // Clear heads
                    *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0002);      // Set head #2
                    while ((*(uint32_t *)PIO_2_addr & 0x0400));              // Drive ready ?
                    usleep( 1000*1000 );
                    READ_drive_from_FPGA(SDRAM_adress);                      // ### FPGA-->Union ###
                    myfile1[20] ='2';
                    WRITE_to_SD_Card1(tohead);                               // ** .mfm track @ head2  **
                    myfile7[20] ='2';
                    WRITE_to_SD_Card7(tohead);                               // ** .gap track @ head2  **
                    myfile6[20] ='2';
                    WRITE_to_SD_Card6(tohead);                               // ** .dsk track @ head2  **
                break;
                case 3:
                    *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x000F);     // Clear heads             
                    *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0004);      // Set head #3
                    while ((*(uint32_t *)PIO_2_addr & 0x0400));              // Drive ready ?
                    usleep( 1000*1000 );
                    READ_drive_from_FPGA(SDRAM_adress);                      // ### FPGA-->Union ###
                    myfile1[20] ='3';
                    WRITE_to_SD_Card1(tohead);                               // ** .mfm track @ head3  **
                    myfile7[20] ='3';
                    WRITE_to_SD_Card7(tohead);                               // ** .gap track @ head3  **
                    myfile6[20] ='3';
                    WRITE_to_SD_Card6(tohead);                               // ** .dsk track @ head3  **
                break;
                case 4:
                    *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode&~0x000F);     // Clear heads             
                    *(uint32_t *)PIO_2_addr = (cl_mode=cl_mode|0x0008);      // Set head #4
                    while ((*(uint32_t *)PIO_2_addr & 0x0400));              // Drive ready ?
                    usleep( 1000*1000 );
                    READ_drive_from_FPGA(SDRAM_adress);                      // ### FPGA-->Union ###
                    myfile1[20] ='4';
                    WRITE_to_SD_Card1(tohead);                               // ** .mfm track @ head4  **
                    myfile7[20] ='4';
                    WRITE_to_SD_Card7(tohead);                               // ** .gap track @ head4  **
                    myfile6[20] ='4';
                    WRITE_to_SD_Card6(tohead);                               // ** .dsk track @ head4  **
                break;
                case 5:
                    printf("\r       Trigger DataAM , (4Hex, like A5F8)  : ");
                    scanf("%4x", &trigger);
                    DataAM = trigger;
                    *(uint32_t *)PIO_3_addr = DataAM ;
                    DataAM_lsb = (unsigned)DataAM & 0xff;     // mask the lower 8 bits
                    DataAM_msb = (unsigned)DataAM >> 8;       // shift the higher 8 bits
                break;
            }       
        }
        //
        *(uint32_t *)PIO_1_addr = (mode=mode&~0x0008);           // Disable  Clone Sequenzer
        //
        //----------------------------------------------------------------------------------------------------------------------
        while ( ~ *(uint32_t *)PIO_1_addr & 0x8000 );   // Reset/Exit,       = Button 1 released
        usleep( 500*1000 );
        while ( ~ *(uint32_t *)PIO_1_addr & 0x4000 );   // Reconfig/Restart, = Button 2 released
        usleep( 500*1000 );
        printf("\x07\n\n\r  Press RESET/Button-1 for exit, Reconfig/Button-2 for restart  \n\r");
        priwhile = 2;
        while(priwhile == 2) {
            if ( ~ *(uint32_t *)PIO_1_addr & 0x4000 ) {  // Reconfig/Restart
                usleep( 500*1000 );
                secwhile = 0;
                priwhile = 0;
            }
            if ( ~ *(uint32_t *)PIO_1_addr & 0x8000 ) {  // Reset/EXit
                printf("\x07\n\n\r    Servus & Bye\n\r\n");
                fflush(stdout);
                usleep( 500*1000 );
                secwhile = 1;
                priwhile = 1;
            }
        }
    } // Primary while
    return 0;
}